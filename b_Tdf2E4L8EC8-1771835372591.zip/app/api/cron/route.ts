import { NextResponse } from "next/server";
import {
  processRealTimePaymentChecks,
  processAutoDelete,
} from "@/lib/bot-handlers";
import { cleanupExpired } from "@/lib/api-client";

export const maxDuration = 60;

export async function GET(request: Request) {
  // Verify cron secret (optional security layer)
  const authHeader = request.headers.get("authorization");
  const cronSecret = process.env.CRON_SECRET;

  if (cronSecret && authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const results = await Promise.allSettled([
      processRealTimePaymentChecks(),
      processAutoDelete(),
      cleanupExpired(),
    ]);

    return NextResponse.json({
      ok: true,
      timestamp: new Date().toISOString(),
      results: results.map((r, i) => ({
        task: ["payment_checks", "auto_delete", "cleanup"][i],
        status: r.status,
      })),
    });
  } catch (error) {
    console.error("Cron error:", error);
    return NextResponse.json(
      { ok: false, error: "Cron processing failed" },
      { status: 500 }
    );
  }
}
