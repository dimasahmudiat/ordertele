import { NextResponse } from "next/server";
import {
  handleTextMessage,
  handleCallback,
  handleBroadcastContent,
  processRealTimePaymentChecks,
  processAutoDelete,
} from "@/lib/bot-handlers";
import { cleanupExpired } from "@/lib/api-client";

export const maxDuration = 60;

export async function POST(request: Request) {
  try {
    const update = await request.json();

    // Process auto-delete and real-time payment checks on every request
    // (same behavior as PHP version)
    const bgTasks = Promise.allSettled([
      processRealTimePaymentChecks(),
      processAutoDelete(),
      cleanupExpired(),
    ]);

    // Handle callback queries
    if (update.callback_query) {
      await handleCallback(update);
      await bgTasks;
      return NextResponse.json({ ok: true });
    }

    // Handle messages
    if (update.message) {
      const chatId = String(update.message.chat.id);
      const text = update.message.text || "";
      const firstName = update.message.chat.first_name || "User";
      const username = update.message.chat.username || "";

      // Check if admin is in broadcast mode and handle broadcast content
      const handled = await handleBroadcastContent(chatId, update);
      if (handled) {
        await bgTasks;
        return NextResponse.json({ ok: true });
      }

      // Handle text messages
      if (text) {
        await handleTextMessage(chatId, text, firstName, username);
      }
    }

    await bgTasks;
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Webhook error:", error);
    return NextResponse.json({ ok: true });
  }
}

export async function GET() {
  return NextResponse.json({
    status: "Bot webhook is running",
    timestamp: new Date().toISOString(),
  });
}
