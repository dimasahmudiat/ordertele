"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";

interface Stats {
  total_users: number;
  orders_today: number;
  revenue_today: number;
  total_orders: number;
  total_revenue: number;
  pending_orders: number;
}

interface Order {
  order_id: string;
  chat_id: string;
  game_type: string;
  duration: number;
  amount: number;
  key_type: string;
  status: string;
  created_at: string;
}

function formatRupiah(amount: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(amount);
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case "completed":
      return (
        <Badge className="bg-emerald-500/15 text-emerald-400 border-emerald-500/25 hover:bg-emerald-500/20">
          Completed
        </Badge>
      );
    case "pending":
      return (
        <Badge className="bg-amber-500/15 text-amber-400 border-amber-500/25 hover:bg-amber-500/20">
          Pending
        </Badge>
      );
    case "expired":
      return (
        <Badge className="bg-red-500/15 text-red-400 border-red-500/25 hover:bg-red-500/20">
          Expired
        </Badge>
      );
    case "cancelled":
      return (
        <Badge className="bg-zinc-500/15 text-zinc-400 border-zinc-500/25 hover:bg-zinc-500/20">
          Cancelled
        </Badge>
      );
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

function GameBadge({ type }: { type: string }) {
  if (type === "ff") {
    return (
      <Badge className="bg-blue-500/15 text-blue-400 border-blue-500/25 hover:bg-blue-500/20">
        FF
      </Badge>
    );
  }
  return (
    <Badge className="bg-cyan-500/15 text-cyan-400 border-cyan-500/25 hover:bg-cyan-500/20">
      FF MAX
    </Badge>
  );
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch("/api/dashboard");
      const data = await res.json();

      if (data.success) {
        setStats(data.stats);
        setOrders(data.orders || []);
        setError(null);
      } else {
        setError("Gagal memuat data. Pastikan backend PHP sudah aktif.");
      }
    } catch {
      setError("Tidak bisa terhubung ke server. Pastikan environment variables sudah diset.");
    } finally {
      setLoading(false);
      setLastUpdated(new Date());
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-muted border-t-primary" />
          <p className="text-muted-foreground font-sans text-sm">
            Memuat dashboard...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <svg
                className="h-5 w-5 text-primary-foreground"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 20V10" />
                <path d="M18 20V4" />
                <path d="M6 20v-4" />
              </svg>
            </div>
            <div>
              <h1 className="font-sans text-lg font-semibold text-foreground">
                Bot Order Dashboard
              </h1>
              <p className="font-sans text-xs text-muted-foreground">
                Monitoring & Statistik
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {lastUpdated && (
              <span className="font-mono text-xs text-muted-foreground">
                Update:{" "}
                {lastUpdated.toLocaleTimeString("id-ID", {
                  timeZone: "Asia/Jakarta",
                })}
              </span>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={fetchData}
              className="font-sans text-xs"
            >
              Refresh
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-6">
        {error && (
          <Card className="mb-6 border-destructive/50 bg-destructive/5">
            <CardContent className="py-4">
              <p className="font-sans text-sm text-destructive">{error}</p>
              <p className="font-sans text-xs text-muted-foreground mt-1">
                {"Pastikan API_BASE_URL dan API_SECRET_KEY sudah dikonfigurasi dengan benar."}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="font-sans text-sm font-medium text-muted-foreground">
                Total Users
              </CardTitle>
              <svg
                className="h-4 w-4 text-muted-foreground"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="font-mono text-2xl font-bold text-foreground">
                {stats?.total_users?.toLocaleString() || "0"}
              </div>
              <p className="font-sans text-xs text-muted-foreground">
                Pengguna terdaftar
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="font-sans text-sm font-medium text-muted-foreground">
                Orders Hari Ini
              </CardTitle>
              <svg
                className="h-4 w-4 text-muted-foreground"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
                <path d="M3 6h18" />
                <path d="M16 10a4 4 0 0 1-8 0" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="font-mono text-2xl font-bold text-foreground">
                {stats?.orders_today?.toLocaleString() || "0"}
              </div>
              <p className="font-sans text-xs text-muted-foreground">
                Transaksi selesai
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="font-sans text-sm font-medium text-muted-foreground">
                Revenue Hari Ini
              </CardTitle>
              <svg
                className="h-4 w-4 text-muted-foreground"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="12" x2="12" y1="2" y2="22" />
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="font-mono text-2xl font-bold text-foreground">
                {formatRupiah(stats?.revenue_today || 0)}
              </div>
              <p className="font-sans text-xs text-muted-foreground">
                Pendapatan hari ini
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="font-sans text-sm font-medium text-muted-foreground">
                Total Revenue
              </CardTitle>
              <svg
                className="h-4 w-4 text-muted-foreground"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 20V10" />
                <path d="M18 20V4" />
                <path d="M6 20v-4" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="font-mono text-2xl font-bold text-foreground">
                {formatRupiah(stats?.total_revenue || 0)}
              </div>
              <p className="font-sans text-xs text-muted-foreground">
                {stats?.total_orders || 0} total orders |{" "}
                {stats?.pending_orders || 0} pending
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Orders Table */}
        <Card>
          <CardHeader>
            <CardTitle className="font-sans text-base">
              Recent Orders
            </CardTitle>
          </CardHeader>
          <CardContent>
            {orders.length === 0 ? (
              <p className="font-sans text-sm text-muted-foreground py-8 text-center">
                Belum ada order. Bot akan mencatat order di sini setelah aktif.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="font-sans">Order ID</TableHead>
                      <TableHead className="font-sans">Chat ID</TableHead>
                      <TableHead className="font-sans">Game</TableHead>
                      <TableHead className="font-sans">Durasi</TableHead>
                      <TableHead className="font-sans">Harga</TableHead>
                      <TableHead className="font-sans">Tipe</TableHead>
                      <TableHead className="font-sans">Status</TableHead>
                      <TableHead className="font-sans">Waktu</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order, i) => (
                      <TableRow key={`${order.order_id}-${i}`}>
                        <TableCell className="font-mono text-xs">
                          {order.order_id}
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {order.chat_id}
                        </TableCell>
                        <TableCell>
                          <GameBadge type={order.game_type} />
                        </TableCell>
                        <TableCell className="font-sans text-sm">
                          {order.duration}d
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {formatRupiah(order.amount)}
                        </TableCell>
                        <TableCell className="font-sans text-xs capitalize">
                          {order.key_type}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={order.status} />
                        </TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          {new Date(order.created_at).toLocaleString("id-ID", {
                            timeZone: "Asia/Jakarta",
                            day: "2-digit",
                            month: "2-digit",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Setup Instructions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="font-sans text-base">
              Setup Instructions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="font-sans text-sm text-muted-foreground space-y-2">
              <p className="font-medium text-foreground">
                1. Upload PHP Backend ke Hosting
              </p>
              <p className="text-xs">
                {"Download file dari /php-backend/ dan upload ke dimzmods.my.id/botorder/"}
              </p>

              <p className="font-medium text-foreground mt-3">
                2. Setup Database
              </p>
              <p className="text-xs">
                {"Jalankan setup_db.sql di phpMyAdmin untuk membuat tabel"}
              </p>

              <p className="font-medium text-foreground mt-3">
                3. Konfigurasi config.php
              </p>
              <p className="text-xs">
                {"Edit config.php dengan kredensial database dan API key Anda"}
              </p>

              <p className="font-medium text-foreground mt-3">
                4. Set Environment Variables di Vercel
              </p>
              <p className="text-xs">
                {"BOT_TOKEN, API_SECRET_KEY, API_BASE_URL, WELCOME_IMAGE, ADMIN_CHAT_ID"}
              </p>

              <p className="font-medium text-foreground mt-3">
                5. Set Webhook Telegram
              </p>
              <p className="text-xs">
                {"Buka: https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://<YOUR-DOMAIN>/api/webhook"}
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
