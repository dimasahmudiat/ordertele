-- setup_db.sql - Jalankan query ini di phpMyAdmin atau MySQL CLI
-- Database untuk Bot Order Telegram

-- Tabel lisensi Free Fire
CREATE TABLE IF NOT EXISTS `freefire` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `uuid` VARCHAR(255) DEFAULT '',
  `expDate` DATETIME NOT NULL,
  `status` VARCHAR(10) DEFAULT '2',
  `reference` VARCHAR(255) DEFAULT '',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_username` (`username`),
  INDEX `idx_username_password` (`username`, `password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel lisensi Free Fire Max
CREATE TABLE IF NOT EXISTS `ffmax` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `uuid` VARCHAR(255) DEFAULT '',
  `expDate` DATETIME NOT NULL,
  `status` VARCHAR(10) DEFAULT '2',
  `reference` VARCHAR(255) DEFAULT '',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_username` (`username`),
  INDEX `idx_username_password` (`username`, `password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel pending orders
CREATE TABLE IF NOT EXISTS `pending_orders` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `order_id` VARCHAR(255) NOT NULL,
  `chat_id` VARCHAR(255) NOT NULL,
  `game_type` VARCHAR(50) NOT NULL,
  `duration` INT(11) NOT NULL,
  `amount` INT(11) NOT NULL,
  `deposit_code` VARCHAR(255) NOT NULL,
  `key_type` VARCHAR(50) NOT NULL,
  `manual_username` VARCHAR(255) DEFAULT '',
  `manual_password` VARCHAR(255) DEFAULT '',
  `status` VARCHAR(50) DEFAULT 'pending',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_chat_id` (`chat_id`),
  INDEX `idx_deposit_code` (`deposit_code`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel user states (untuk tracking state percakapan)
CREATE TABLE IF NOT EXISTS `user_states` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `chat_id` VARCHAR(255) NOT NULL,
  `state` VARCHAR(255) NOT NULL,
  `data` TEXT DEFAULT NULL,
  `error_count` INT(11) DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_chat_id` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel user points
CREATE TABLE IF NOT EXISTS `user_points` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `chat_id` VARCHAR(255) NOT NULL,
  `points` INT(11) DEFAULT 0,
  `last_reason` VARCHAR(255) DEFAULT '',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_chat_id` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel bot users (untuk broadcast)
CREATE TABLE IF NOT EXISTS `bot_users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `chat_id` VARCHAR(255) NOT NULL,
  `first_name` VARCHAR(255) DEFAULT '',
  `username` VARCHAR(255) DEFAULT '',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_chat_id` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel admin states (untuk broadcast flow)
CREATE TABLE IF NOT EXISTS `admin_states` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `chat_id` VARCHAR(255) NOT NULL,
  `state` VARCHAR(255) NOT NULL,
  `data` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_chat_id` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel broadcast history
CREATE TABLE IF NOT EXISTS `broadcast_history` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `admin_chat_id` VARCHAR(255) NOT NULL,
  `broadcast_type` VARCHAR(50) NOT NULL,
  `message_type` VARCHAR(50) NOT NULL,
  `total_users` INT(11) DEFAULT 0,
  `success_count` INT(11) DEFAULT 0,
  `failed_count` INT(11) DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel payment checks (menggantikan payment_checks.json)
CREATE TABLE IF NOT EXISTS `payment_checks` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `chat_id` VARCHAR(255) NOT NULL,
  `message_id` VARCHAR(255) NOT NULL,
  `start_time` INT(11) NOT NULL,
  `end_time` INT(11) NOT NULL,
  `last_check` INT(11) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_chat_id` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabel message schedules (menggantikan schedule.json)
CREATE TABLE IF NOT EXISTS `message_schedules` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `chat_id` VARCHAR(255) NOT NULL,
  `message_id` VARCHAR(255) NOT NULL,
  `delete_time` INT(11) NOT NULL,
  `type` VARCHAR(50) DEFAULT 'pending',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_delete_time` (`delete_time`),
  INDEX `idx_chat_id_message_id` (`chat_id`, `message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
