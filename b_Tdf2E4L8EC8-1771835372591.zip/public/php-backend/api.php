<?php
// api.php - REST API Backend untuk Bot Order
// Upload file ini ke: dimzmods.my.id/botorder/api.php
require_once 'config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Authenticate request
$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? '';
if ($apiKey !== API_SECRET_KEY) {
    logAPI("Unauthorized access attempt with key: $apiKey");
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// Get action
$action = $_POST['action'] ?? $_GET['action'] ?? '';
if (empty($action)) {
    echo json_encode(['success' => false, 'error' => 'No action specified']);
    exit;
}

logAPI("Action: $action");

$conn = getDBConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

try {
    switch ($action) {
        // ============================================================
        // USERNAME / LICENSE OPERATIONS
        // ============================================================
        case 'check_username':
            $username = $_POST['username'] ?? '';
            $table = $_POST['table'] ?? '';
            
            if (empty($username)) {
                echo json_encode(['success' => true, 'exists' => false]);
                break;
            }
            
            if (!empty($table) && in_array($table, ['freefire', 'ffmax'])) {
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM `$table` WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_assoc();
                echo json_encode(['success' => true, 'exists' => $result['count'] > 0]);
            } else {
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM freefire WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $ff = $stmt->get_result()->fetch_assoc()['count'];
                $stmt->close();
                
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM ffmax WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $ffmax = $stmt->get_result()->fetch_assoc()['count'];
                
                echo json_encode(['success' => true, 'exists' => ($ff + $ffmax) > 0]);
            }
            break;
            
        case 'get_user':
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $game_type = $_POST['game_type'] ?? '';
            
            if ($game_type == 'ff') {
                $stmt = $conn->prepare("SELECT *, 'ff' as game_type FROM freefire WHERE username = ? AND password = ?");
                $stmt->bind_param("ss", $username, $password);
            } elseif ($game_type == 'ffmax') {
                $stmt = $conn->prepare("SELECT *, 'ffmax' as game_type FROM ffmax WHERE username = ? AND password = ?");
                $stmt->bind_param("ss", $username, $password);
            } else {
                $stmt = $conn->prepare("SELECT *, 'ff' as game_type FROM freefire WHERE username = ? AND password = ? UNION ALL SELECT *, 'ffmax' as game_type FROM ffmax WHERE username = ? AND password = ? LIMIT 1");
                $stmt->bind_param("ssss", $username, $password, $username, $password);
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                echo json_encode(['success' => true, 'user' => $result->fetch_assoc()]);
            } else {
                echo json_encode(['success' => true, 'user' => null]);
            }
            break;
            
        case 'save_license':
            $table = $_POST['table'] ?? '';
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $duration = intval($_POST['duration'] ?? 0);
            $reference = $_POST['reference'] ?? 'DIMZ1945';
            
            if (!in_array($table, ['freefire', 'ffmax'])) {
                echo json_encode(['success' => false, 'error' => 'Invalid table']);
                break;
            }
            
            // Check if username exists
            $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM `$table` WHERE username = ?");
            $checkStmt->bind_param("s", $username);
            $checkStmt->execute();
            $exists = $checkStmt->get_result()->fetch_assoc()['count'] > 0;
            $checkStmt->close();
            
            if ($exists) {
                echo json_encode(['success' => false, 'error' => 'Username already exists']);
                break;
            }
            
            $expDate = date('Y-m-d H:i:s', strtotime("+$duration days"));
            $uuid = "";
            $status = "2";
            
            $stmt = $conn->prepare("INSERT INTO `$table` (username, password, uuid, expDate, status, reference, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("ssssss", $username, $password, $uuid, $expDate, $status, $reference);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        case 'extend_license':
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $duration = intval($_POST['duration'] ?? 0);
            $game_type = $_POST['game_type'] ?? '';
            
            $table = ($game_type == 'ff') ? 'freefire' : 'ffmax';
            
            $stmt = $conn->prepare("SELECT expDate FROM `$table` WHERE username = ? AND password = ?");
            $stmt->bind_param("ss", $username, $password);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                $currentExpDate = $user['expDate'];
                $stmt->close();
                
                if (strtotime($currentExpDate) < time()) {
                    $newExpDate = date('Y-m-d H:i:s', strtotime("+$duration days"));
                } else {
                    $newExpDate = date('Y-m-d H:i:s', strtotime("$currentExpDate +$duration days"));
                }
                
                $stmt = $conn->prepare("UPDATE `$table` SET expDate = ? WHERE username = ? AND password = ?");
                $stmt->bind_param("sss", $newExpDate, $username, $password);
                $result = $stmt->execute();
                $affected = $stmt->affected_rows;
                
                echo json_encode(['success' => $affected > 0, 'new_exp_date' => $newExpDate]);
            } else {
                echo json_encode(['success' => false, 'error' => 'User not found']);
            }
            break;
            
        // ============================================================
        // PENDING ORDERS
        // ============================================================
        case 'save_pending_order':
            $order_id = $_POST['order_id'] ?? '';
            $chat_id = $_POST['chat_id'] ?? '';
            $game_type = $_POST['game_type'] ?? '';
            $duration = intval($_POST['duration'] ?? 0);
            $amount = intval($_POST['amount'] ?? 0);
            $deposit_code = $_POST['deposit_code'] ?? '';
            $key_type = $_POST['key_type'] ?? '';
            $manual_username = $_POST['manual_username'] ?? '';
            $manual_password = $_POST['manual_password'] ?? '';
            
            $stmt = $conn->prepare("INSERT INTO pending_orders (order_id, chat_id, game_type, duration, amount, deposit_code, key_type, manual_username, manual_password, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())");
            $stmt->bind_param("ssssissss", $order_id, $chat_id, $game_type, $duration, $amount, $deposit_code, $key_type, $manual_username, $manual_password);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        case 'get_pending_order':
            $chat_id = $_POST['chat_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT * FROM pending_orders WHERE chat_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            echo json_encode(['success' => true, 'order' => $result->fetch_assoc()]);
            break;
            
        case 'update_order_status':
            $deposit_code = $_POST['deposit_code'] ?? '';
            $status = $_POST['status'] ?? '';
            
            $stmt = $conn->prepare("UPDATE pending_orders SET status = ?, updated_at = NOW() WHERE deposit_code = ?");
            $stmt->bind_param("ss", $status, $deposit_code);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        // ============================================================
        // USER STATE MANAGEMENT
        // ============================================================
        case 'save_user_state':
            $chat_id = $_POST['chat_id'] ?? '';
            $state = $_POST['state'] ?? '';
            $data = $_POST['data'] ?? '{}';
            
            $stmt = $conn->prepare("SELECT id FROM user_states WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $stmt->close();
            
            if ($result->num_rows > 0) {
                $stmt = $conn->prepare("UPDATE user_states SET state = ?, data = ?, error_count = 0, updated_at = NOW() WHERE chat_id = ?");
                $stmt->bind_param("sss", $state, $data, $chat_id);
            } else {
                $stmt = $conn->prepare("INSERT INTO user_states (chat_id, state, data, error_count, created_at, updated_at) VALUES (?, ?, ?, 0, NOW(), NOW())");
                $stmt->bind_param("sss", $chat_id, $state, $data);
            }
            
            $result = $stmt->execute();
            echo json_encode(['success' => $result]);
            break;
            
        case 'get_user_state':
            $chat_id = $_POST['chat_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT state, data, error_count FROM user_states WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $row['data'] = json_decode($row['data'], true);
                echo json_encode(['success' => true, 'state' => $row]);
            } else {
                echo json_encode(['success' => true, 'state' => null]);
            }
            break;
            
        case 'clear_user_state':
            $chat_id = $_POST['chat_id'] ?? '';
            
            $stmt = $conn->prepare("DELETE FROM user_states WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        case 'update_error_count':
            $chat_id = $_POST['chat_id'] ?? '';
            $error_count = intval($_POST['error_count'] ?? 0);
            
            $stmt = $conn->prepare("UPDATE user_states SET error_count = ?, updated_at = NOW() WHERE chat_id = ?");
            $stmt->bind_param("is", $error_count, $chat_id);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        // ============================================================
        // POINTS SYSTEM
        // ============================================================
        case 'get_user_points':
            $chat_id = $_POST['chat_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT points FROM user_points WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo json_encode(['success' => true, 'points' => intval($row['points'])]);
            } else {
                echo json_encode(['success' => true, 'points' => 0]);
            }
            break;
            
        case 'add_user_points':
            $chat_id = $_POST['chat_id'] ?? '';
            $points = intval($_POST['points'] ?? 0);
            $reason = $_POST['reason'] ?? '';
            
            $stmt = $conn->prepare("SELECT id FROM user_points WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $stmt->close();
            
            if ($result->num_rows > 0) {
                $stmt = $conn->prepare("UPDATE user_points SET points = points + ?, last_reason = ?, updated_at = NOW() WHERE chat_id = ?");
                $stmt->bind_param("iss", $points, $reason, $chat_id);
            } else {
                $stmt = $conn->prepare("INSERT INTO user_points (chat_id, points, last_reason, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
                $stmt->bind_param("sis", $chat_id, $points, $reason);
            }
            
            $result = $stmt->execute();
            echo json_encode(['success' => $result]);
            break;
            
        case 'redeem_user_points':
            $chat_id = $_POST['chat_id'] ?? '';
            $points = intval($_POST['points'] ?? 0);
            $reason = $_POST['reason'] ?? '';
            
            // Check if user has enough points
            $stmt = $conn->prepare("SELECT points FROM user_points WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if (intval($row['points']) >= $points) {
                    $stmt->close();
                    $stmt = $conn->prepare("UPDATE user_points SET points = points - ?, last_reason = ?, updated_at = NOW() WHERE chat_id = ?");
                    $stmt->bind_param("iss", $points, $reason, $chat_id);
                    $result = $stmt->execute();
                    echo json_encode(['success' => $result]);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Insufficient points']);
                }
            } else {
                echo json_encode(['success' => false, 'error' => 'User not found']);
            }
            break;
            
        // ============================================================
        // BOT USERS (untuk broadcast)
        // ============================================================
        case 'save_bot_user':
            $chat_id = $_POST['chat_id'] ?? '';
            $first_name = $_POST['first_name'] ?? '';
            $username = $_POST['username'] ?? '';
            
            $stmt = $conn->prepare("SELECT id FROM bot_users WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $stmt->close();
            
            if ($result->num_rows > 0) {
                $stmt = $conn->prepare("UPDATE bot_users SET first_name = ?, username = ?, is_active = 1, updated_at = NOW() WHERE chat_id = ?");
                $stmt->bind_param("sss", $first_name, $username, $chat_id);
            } else {
                $stmt = $conn->prepare("INSERT INTO bot_users (chat_id, first_name, username, is_active, created_at, updated_at) VALUES (?, ?, ?, 1, NOW(), NOW())");
                $stmt->bind_param("sss", $chat_id, $first_name, $username);
            }
            
            $result = $stmt->execute();
            echo json_encode(['success' => $result]);
            break;
            
        case 'get_all_bot_users':
            $stmt = $conn->prepare("SELECT chat_id FROM bot_users WHERE is_active = 1");
            $stmt->execute();
            $result = $stmt->get_result();
            
            $users = [];
            while ($row = $result->fetch_assoc()) {
                $users[] = $row['chat_id'];
            }
            
            echo json_encode(['success' => true, 'users' => $users]);
            break;
            
        case 'get_total_bot_users':
            $stmt = $conn->prepare("SELECT COUNT(*) as total FROM bot_users WHERE is_active = 1");
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            
            echo json_encode(['success' => true, 'total' => intval($result['total'])]);
            break;
            
        // ============================================================
        // ADMIN STATE (untuk broadcast flow)
        // ============================================================
        case 'save_admin_state':
            $chat_id = $_POST['chat_id'] ?? '';
            $state = $_POST['state'] ?? '';
            
            $stmt = $conn->prepare("SELECT id FROM admin_states WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $stmt->close();
            
            if ($result->num_rows > 0) {
                $stmt = $conn->prepare("UPDATE admin_states SET state = ?, updated_at = NOW() WHERE chat_id = ?");
                $stmt->bind_param("ss", $state, $chat_id);
            } else {
                $stmt = $conn->prepare("INSERT INTO admin_states (chat_id, state, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
                $stmt->bind_param("ss", $chat_id, $state);
            }
            
            $result = $stmt->execute();
            echo json_encode(['success' => $result]);
            break;
            
        case 'get_admin_state':
            $chat_id = $_POST['chat_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT state FROM admin_states WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo json_encode(['success' => true, 'admin_state' => $row]);
            } else {
                echo json_encode(['success' => true, 'admin_state' => null]);
            }
            break;
            
        case 'clear_admin_state':
            $chat_id = $_POST['chat_id'] ?? '';
            
            $stmt = $conn->prepare("DELETE FROM admin_states WHERE chat_id = ?");
            $stmt->bind_param("s", $chat_id);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        // ============================================================
        // BROADCAST
        // ============================================================
        case 'save_broadcast_history':
            $admin_chat_id = $_POST['admin_chat_id'] ?? '';
            $broadcast_type = $_POST['broadcast_type'] ?? '';
            $message_type = $_POST['message_type'] ?? '';
            $total_users = intval($_POST['total_users'] ?? 0);
            $success_count = intval($_POST['success_count'] ?? 0);
            $failed_count = intval($_POST['failed_count'] ?? 0);
            
            $stmt = $conn->prepare("INSERT INTO broadcast_history (admin_chat_id, broadcast_type, message_type, total_users, success_count, failed_count, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("sssiii", $admin_chat_id, $broadcast_type, $message_type, $total_users, $success_count, $failed_count);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        // ============================================================
        // PAYMENT CHECKS (replaces payment_checks.json)
        // ============================================================
        case 'save_payment_check':
            $chat_id = $_POST['chat_id'] ?? '';
            $message_id = $_POST['message_id'] ?? '';
            $start_time = intval($_POST['start_time'] ?? time());
            $end_time = intval($_POST['end_time'] ?? (time() + ORDER_TIMEOUT));
            
            $stmt = $conn->prepare("INSERT INTO payment_checks (chat_id, message_id, start_time, end_time, last_check, status, created_at) VALUES (?, ?, ?, ?, ?, 'active', NOW())");
            $stmt->bind_param("ssiis", $chat_id, $message_id, $start_time, $end_time, $start_time);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        case 'get_active_payment_checks':
            $stmt = $conn->prepare("SELECT * FROM payment_checks WHERE status = 'active'");
            $stmt->execute();
            $result = $stmt->get_result();
            
            $checks = [];
            while ($row = $result->fetch_assoc()) {
                $checks[] = $row;
            }
            
            echo json_encode(['success' => true, 'checks' => $checks]);
            break;
            
        case 'update_payment_check':
            $id = intval($_POST['id'] ?? 0);
            $last_check = intval($_POST['last_check'] ?? time());
            $status = $_POST['status'] ?? 'active';
            
            $stmt = $conn->prepare("UPDATE payment_checks SET last_check = ?, status = ? WHERE id = ?");
            $stmt->bind_param("isi", $last_check, $status, $id);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        case 'cleanup_payment_checks':
            $stmt = $conn->prepare("DELETE FROM payment_checks WHERE status != 'active' OR end_time < ?");
            $currentTime = time();
            $stmt->bind_param("i", $currentTime);
            $result = $stmt->execute();
            $deleted = $stmt->affected_rows;
            
            echo json_encode(['success' => true, 'deleted' => $deleted]);
            break;
            
        // ============================================================
        // MESSAGE SCHEDULES (replaces schedule.json)
        // ============================================================
        case 'save_message_schedule':
            $chat_id = $_POST['chat_id'] ?? '';
            $message_id = $_POST['message_id'] ?? '';
            $delay_seconds = intval($_POST['delay_seconds'] ?? ORDER_TIMEOUT);
            $type = $_POST['type'] ?? 'pending';
            
            $delete_time = time() + $delay_seconds;
            
            $stmt = $conn->prepare("INSERT INTO message_schedules (chat_id, message_id, delete_time, type, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->bind_param("ssis", $chat_id, $message_id, $delete_time, $type);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result]);
            break;
            
        case 'get_due_schedules':
            $current_time = time();
            
            $stmt = $conn->prepare("SELECT * FROM message_schedules WHERE delete_time <= ? AND type = 'pending'");
            $stmt->bind_param("i", $current_time);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $schedules = [];
            while ($row = $result->fetch_assoc()) {
                $schedules[] = $row;
            }
            
            echo json_encode(['success' => true, 'schedules' => $schedules]);
            break;
            
        case 'delete_message_schedule':
            $chat_id = $_POST['chat_id'] ?? '';
            $message_id = $_POST['message_id'] ?? '';
            
            $stmt = $conn->prepare("DELETE FROM message_schedules WHERE chat_id = ? AND message_id = ?");
            $stmt->bind_param("ss", $chat_id, $message_id);
            $result = $stmt->execute();
            
            echo json_encode(['success' => $result, 'deleted' => $stmt->affected_rows > 0]);
            break;
            
        case 'cleanup_schedules':
            $stmt = $conn->prepare("DELETE FROM message_schedules WHERE delete_time < ?");
            $pastTime = time() - 3600; // Clean schedules older than 1 hour past due
            $stmt->bind_param("i", $pastTime);
            $result = $stmt->execute();
            
            echo json_encode(['success' => true, 'deleted' => $stmt->affected_rows]);
            break;
            
        // ============================================================
        // PAYMENT API PROXY
        // ============================================================
        case 'create_payment':
            $order_id = $_POST['order_id'] ?? '';
            $amount = intval($_POST['amount'] ?? 0);
            
            $url = PAYMENT_BASE_URL . "?action=get-deposit&kode=" . urlencode($order_id) . "&nominal=" . $amount . "&apikey=" . PAYMENT_API_KEY;
            
            $response = @file_get_contents($url);
            if ($response === false) {
                echo json_encode(['success' => false, 'error' => 'Payment API unreachable']);
            } else {
                $data = json_decode($response, true);
                echo json_encode(['success' => true, 'payment' => $data]);
            }
            break;
            
        case 'check_payment':
            $deposit_code = $_POST['deposit_code'] ?? '';
            
            $url = PAYMENT_BASE_URL . "?action=get-mutasi&kode=" . urlencode($deposit_code) . "&apikey=" . PAYMENT_API_KEY;
            
            $response = @file_get_contents($url);
            if ($response === false) {
                echo json_encode(['success' => false, 'error' => 'Payment API unreachable']);
            } else {
                $data = json_decode($response, true);
                $isPaid = ($data && $data['status'] && isset($data['data']['status']) && $data['data']['status'] == 'Success');
                echo json_encode(['success' => true, 'is_paid' => $isPaid, 'payment_data' => $data]);
            }
            break;
            
        // ============================================================
        // CLEANUP
        // ============================================================
        case 'cleanup_expired':
            $expiredTime = date('Y-m-d H:i:s', time() - ORDER_TIMEOUT);
            
            $stmt = $conn->prepare("DELETE FROM pending_orders WHERE status = 'pending' AND created_at < ?");
            $stmt->bind_param("s", $expiredTime);
            $result = $stmt->execute();
            $deleted = $stmt->affected_rows;
            
            echo json_encode(['success' => true, 'deleted' => $deleted]);
            break;
            
        // ============================================================
        // DASHBOARD STATS
        // ============================================================
        case 'get_dashboard_stats':
            $stats = [];
            
            // Total bot users
            $result = $conn->query("SELECT COUNT(*) as total FROM bot_users WHERE is_active = 1");
            $stats['total_users'] = intval($result->fetch_assoc()['total']);
            
            // Total orders today
            $today = date('Y-m-d');
            $stmt = $conn->prepare("SELECT COUNT(*) as total FROM pending_orders WHERE DATE(created_at) = ? AND status = 'completed'");
            $stmt->bind_param("s", $today);
            $stmt->execute();
            $stats['orders_today'] = intval($stmt->get_result()->fetch_assoc()['total']);
            $stmt->close();
            
            // Total revenue today
            $stmt = $conn->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM pending_orders WHERE DATE(created_at) = ? AND status = 'completed'");
            $stmt->bind_param("s", $today);
            $stmt->execute();
            $stats['revenue_today'] = intval($stmt->get_result()->fetch_assoc()['total']);
            $stmt->close();
            
            // Total all orders completed
            $result = $conn->query("SELECT COUNT(*) as total FROM pending_orders WHERE status = 'completed'");
            $stats['total_orders'] = intval($result->fetch_assoc()['total']);
            
            // Total revenue all time
            $result = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM pending_orders WHERE status = 'completed'");
            $stats['total_revenue'] = intval($result->fetch_assoc()['total']);
            
            // Pending orders
            $result = $conn->query("SELECT COUNT(*) as total FROM pending_orders WHERE status = 'pending'");
            $stats['pending_orders'] = intval($result->fetch_assoc()['total']);
            
            echo json_encode(['success' => true, 'stats' => $stats]);
            break;
            
        case 'get_recent_orders':
            $limit = intval($_POST['limit'] ?? 20);
            
            $stmt = $conn->prepare("SELECT order_id, chat_id, game_type, duration, amount, key_type, status, created_at FROM pending_orders ORDER BY created_at DESC LIMIT ?");
            $stmt->bind_param("i", $limit);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $orders = [];
            while ($row = $result->fetch_assoc()) {
                $orders[] = $row;
            }
            
            echo json_encode(['success' => true, 'orders' => $orders]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown action: ' . $action]);
            break;
    }
} catch (Exception $e) {
    logAPI("Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} finally {
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        $stmt->close();
    }
    $conn->close();
}
?>
