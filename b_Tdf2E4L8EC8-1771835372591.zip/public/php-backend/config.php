<?php
// config.php - Konfigurasi PHP Backend API untuk Bot Order
// Upload file ini ke: dimzmods.my.id/botorder/config.php

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt');
date_default_timezone_set('Asia/Jakarta');

// ============================================================
// KONFIGURASI - Sesuaikan dengan data hosting Anda
// ============================================================

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'GANTI_DB_USERNAME');
define('DB_PASSWORD', 'GANTI_DB_PASSWORD');
define('DB_NAME', 'GANTI_DB_NAME');

// API Secret Key - Harus sama dengan di Vercel Environment Variables
define('API_SECRET_KEY', 'GANTI_DENGAN_SECRET_KEY_ANDA');

// Payment API Configuration
define('PAYMENT_API_KEY', 'GANTI_PAYMENT_API_KEY');
define('MERCHANT_CODE', 'DIMZ1945');
define('PAYMENT_BASE_URL', 'https://cekid-ariepulsa.my.id/qris/');

// Bot Configuration
define('BOT_TOKEN', 'GANTI_BOT_TOKEN');
define('ORDER_TIMEOUT', 300); // 25 menit dalam detik (5 menit = 300 detik, 25 menit = 1500)
define('PAYMENT_CHECK_INTERVAL', 20); // Cek setiap 20 detik

// ============================================================
// FUNGSI DATABASE
// ============================================================

function getDBConnection() {
    try {
        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
        if ($conn->connect_error) {
            error_log("Database connection failed: " . $conn->connect_error);
            return false;
        }
        $conn->set_charset("utf8mb4");
        return $conn;
    } catch (Exception $e) {
        error_log("Database exception: " . $e->getMessage());
        return false;
    }
}

function logAPI($message) {
    $logFile = __DIR__ . '/api_log.txt';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
}
?>
