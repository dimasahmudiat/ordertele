// HTTP client for PHP backend API at dimzmods.my.id/botorder/api.php
import { API_BASE_URL, API_SECRET_KEY } from "./bot-config";

async function apiRequest(
  action: string,
  params: Record<string, string | number> = {}
) {
  const body = new URLSearchParams();
  body.append("action", action);
  for (const [key, value] of Object.entries(params)) {
    body.append(key, String(value));
  }

  const res = await fetch(API_BASE_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "X-API-Key": API_SECRET_KEY,
    },
    body: body.toString(),
  });

  return res.json();
}

// ============================================================
// USERNAME / LICENSE OPERATIONS
// ============================================================

export async function checkUsername(username: string, table?: string) {
  const params: Record<string, string> = { username };
  if (table) params.table = table;
  const res = await apiRequest("check_username", params);
  return res.exists as boolean;
}

export async function getUser(
  username: string,
  password: string,
  gameType?: string
) {
  const params: Record<string, string> = { username, password };
  if (gameType) params.game_type = gameType;
  const res = await apiRequest("get_user", params);
  return res.user || null;
}

export async function saveLicense(
  table: string,
  username: string,
  password: string,
  duration: number,
  reference = "DIMZ1945"
) {
  const res = await apiRequest("save_license", {
    table,
    username,
    password,
    duration,
    reference,
  });
  return res.success as boolean;
}

export async function extendLicense(
  username: string,
  password: string,
  duration: number,
  gameType: string
) {
  const res = await apiRequest("extend_license", {
    username,
    password,
    duration,
    game_type: gameType,
  });
  return res;
}

// ============================================================
// PENDING ORDERS
// ============================================================

export async function savePendingOrder(params: {
  orderId: string;
  chatId: string;
  gameType: string;
  duration: number;
  amount: number;
  depositCode: string;
  keyType: string;
  manualUsername?: string;
  manualPassword?: string;
}) {
  const res = await apiRequest("save_pending_order", {
    order_id: params.orderId,
    chat_id: params.chatId,
    game_type: params.gameType,
    duration: params.duration,
    amount: params.amount,
    deposit_code: params.depositCode,
    key_type: params.keyType,
    manual_username: params.manualUsername || "",
    manual_password: params.manualPassword || "",
  });
  return res.success as boolean;
}

export async function getPendingOrder(chatId: string) {
  const res = await apiRequest("get_pending_order", { chat_id: chatId });
  return res.order || null;
}

export async function updateOrderStatus(
  depositCode: string,
  status: string
) {
  const res = await apiRequest("update_order_status", {
    deposit_code: depositCode,
    status,
  });
  return res.success as boolean;
}

// ============================================================
// USER STATE
// ============================================================

export async function saveUserState(
  chatId: string,
  state: string,
  data: Record<string, unknown> = {}
) {
  const res = await apiRequest("save_user_state", {
    chat_id: chatId,
    state,
    data: JSON.stringify(data),
  });
  return res.success as boolean;
}

export async function getUserState(chatId: string) {
  const res = await apiRequest("get_user_state", { chat_id: chatId });
  return res.state || null;
}

export async function clearUserState(chatId: string) {
  const res = await apiRequest("clear_user_state", { chat_id: chatId });
  return res.success as boolean;
}

export async function updateErrorCount(
  chatId: string,
  errorCount: number
) {
  const res = await apiRequest("update_error_count", {
    chat_id: chatId,
    error_count: errorCount,
  });
  return res.success as boolean;
}

// ============================================================
// POINTS
// ============================================================

export async function getUserPoints(chatId: string): Promise<number> {
  const res = await apiRequest("get_user_points", { chat_id: chatId });
  return (res.points as number) || 0;
}

export async function addUserPoints(
  chatId: string,
  points: number,
  reason: string
) {
  const res = await apiRequest("add_user_points", {
    chat_id: chatId,
    points,
    reason,
  });
  return res.success as boolean;
}

export async function redeemUserPoints(
  chatId: string,
  points: number,
  reason: string
) {
  const res = await apiRequest("redeem_user_points", {
    chat_id: chatId,
    points,
    reason,
  });
  return res.success as boolean;
}

// ============================================================
// BOT USERS
// ============================================================

export async function saveBotUser(
  chatId: string,
  firstName: string,
  username: string
) {
  const res = await apiRequest("save_bot_user", {
    chat_id: chatId,
    first_name: firstName,
    username,
  });
  return res.success as boolean;
}

export async function getAllBotUsers(): Promise<string[]> {
  const res = await apiRequest("get_all_bot_users");
  return (res.users as string[]) || [];
}

export async function getTotalBotUsers(): Promise<number> {
  const res = await apiRequest("get_total_bot_users");
  return (res.total as number) || 0;
}

// ============================================================
// ADMIN STATE
// ============================================================

export async function saveAdminState(chatId: string, state: string) {
  const res = await apiRequest("save_admin_state", {
    chat_id: chatId,
    state,
  });
  return res.success as boolean;
}

export async function getAdminState(chatId: string) {
  const res = await apiRequest("get_admin_state", { chat_id: chatId });
  return res.admin_state || null;
}

export async function clearAdminState(chatId: string) {
  const res = await apiRequest("clear_admin_state", { chat_id: chatId });
  return res.success as boolean;
}

// ============================================================
// BROADCAST
// ============================================================

export async function saveBroadcastHistory(params: {
  adminChatId: string;
  broadcastType: string;
  messageType: string;
  totalUsers: number;
  successCount: number;
  failedCount: number;
}) {
  const res = await apiRequest("save_broadcast_history", {
    admin_chat_id: params.adminChatId,
    broadcast_type: params.broadcastType,
    message_type: params.messageType,
    total_users: params.totalUsers,
    success_count: params.successCount,
    failed_count: params.failedCount,
  });
  return res.success as boolean;
}

// ============================================================
// PAYMENT CHECKS (replaces payment_checks.json)
// ============================================================

export async function savePaymentCheck(
  chatId: string,
  messageId: string,
  startTime: number,
  endTime: number
) {
  const res = await apiRequest("save_payment_check", {
    chat_id: chatId,
    message_id: messageId,
    start_time: startTime,
    end_time: endTime,
  });
  return res.success as boolean;
}

export async function getActivePaymentChecks() {
  const res = await apiRequest("get_active_payment_checks");
  return res.checks || [];
}

export async function updatePaymentCheck(
  id: number,
  lastCheck: number,
  status: string
) {
  const res = await apiRequest("update_payment_check", {
    id,
    last_check: lastCheck,
    status,
  });
  return res.success as boolean;
}

// ============================================================
// MESSAGE SCHEDULES (replaces schedule.json)
// ============================================================

export async function saveMessageSchedule(
  chatId: string,
  messageId: string,
  delaySeconds: number,
  type = "pending"
) {
  const res = await apiRequest("save_message_schedule", {
    chat_id: chatId,
    message_id: messageId,
    delay_seconds: delaySeconds,
    type,
  });
  return res.success as boolean;
}

export async function getDueSchedules() {
  const res = await apiRequest("get_due_schedules");
  return res.schedules || [];
}

export async function deleteMessageSchedule(
  chatId: string,
  messageId: string
) {
  const res = await apiRequest("delete_message_schedule", {
    chat_id: chatId,
    message_id: messageId,
  });
  return res.success as boolean;
}

// ============================================================
// PAYMENT API
// ============================================================

export async function createPayment(orderId: string, amount: number) {
  const res = await apiRequest("create_payment", {
    order_id: orderId,
    amount,
  });
  if (res.success && res.payment) {
    return res.payment;
  }
  return null;
}

export async function checkPaymentStatus(depositCode: string) {
  const res = await apiRequest("check_payment", {
    deposit_code: depositCode,
  });
  return {
    isPaid: res.is_paid as boolean,
    data: res.payment_data,
  };
}

// ============================================================
// CLEANUP + DASHBOARD
// ============================================================

export async function cleanupExpired() {
  return apiRequest("cleanup_expired");
}

export async function getDashboardStats() {
  const res = await apiRequest("get_dashboard_stats");
  return res.stats || {};
}

export async function getRecentOrders(limit = 20) {
  const res = await apiRequest("get_recent_orders", { limit });
  return res.orders || [];
}
