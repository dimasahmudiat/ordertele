// Bot handlers - all command, text, and callback logic
import {
  PRICES,
  ORDER_TIMEOUT,
  ADMIN_CHAT_ID,
  MERCHANT_CODE,
  formatPrice,
  PAYMENT_CHECK_INTERVAL,
} from "./bot-config";
import {
  sendMessage,
  sendPhoto,
  sendMessageWithImage,
  editMessageSmart,
  deleteMessage,
  answerCallbackQuery,
  sendBroadcastMessage,
} from "./telegram";
import * as api from "./api-client";
import {
  calculatePointsForDuration,
  calculatePointsNeededForDays,
  generateRandomCredentials,
  generateRedeemCredentials,
} from "./points";

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function getBackButton(previousAction = "") {
  const buttons: Array<Array<{ text: string; callback_data: string }>> = [];
  if (previousAction) {
    buttons.push([
      { text: "\u21a9\ufe0f Kembali", callback_data: previousAction },
    ]);
  }
  buttons.push([
    { text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" },
  ]);
  return JSON.stringify({ inline_keyboard: buttons });
}

function isAdmin(chatId: string): boolean {
  return chatId === ADMIN_CHAT_ID;
}

async function notifyAdmin(message: string) {
  if (ADMIN_CHAT_ID) {
    await sendMessage(ADMIN_CHAT_ID, message);
  }
}

// ============================================================
// SHOW MAIN MENU
// ============================================================

async function showMainMenu(
  chatId: string,
  text?: string | null,
  messageId?: number
) {
  const userPoints = await api.getUserPoints(chatId);

  const message =
    text ||
    `\ud83c\udfe0 <b>Menu Utama</b>\n\n\ud83d\udcb0 <b>Point Anda:</b> ${userPoints} points\n\nSilakan pilih menu yang diinginkan:`;

  const keyboard = JSON.stringify({
    inline_keyboard: [
      [{ text: "\ud83d\uded2 Beli Lisensi Baru", callback_data: "new_order" }],
      [
        {
          text: "\u23f0 Extend Masa Aktif",
          callback_data: "extend_user",
        },
      ],
      [{ text: "\ud83c\udf81 Tukar Point", callback_data: "redeem_points" }],
      [{ text: "\u2139\ufe0f Bantuan", callback_data: "help" }],
    ],
  });

  if (messageId) {
    return editMessageSmart(chatId, messageId, message, keyboard);
  }
  return sendMessageWithImage(chatId, message, keyboard);
}

// ============================================================
// LICENSE SUCCESS MESSAGES
// ============================================================

async function sendLicenseToUser(
  chatId: string,
  gameType: string,
  duration: number,
  credentials: { username: string; password: string },
  keyType = "random"
) {
  const gameName = gameType === "ff" ? "FREE FIRE" : "FREE FIRE MAX";
  const now = new Date();
  const expiry = new Date(now.getTime() + duration * 24 * 60 * 60 * 1000);
  const expiryDate = formatDateWIB(expiry);

  const pointsEarned = calculatePointsForDuration(duration);
  await api.addUserPoints(
    chatId,
    pointsEarned,
    `Pembelian lisensi ${duration} hari`
  );
  const userPoints = await api.getUserPoints(chatId);

  const message =
    `\ud83c\udf89 <b>PEMBAYARAN BERHASIL!</b>\n\n` +
    `Terima kasih telah membeli lisensi <b>${gameName}</b>\n` +
    `Durasi: <b>${duration} Hari</b>\n` +
    `Tipe Key: <b>${keyType === "manual" ? "MANUAL" : "RANDOM"}</b>\n\n` +
    `\ud83d\udcf1 <b>AKUN ANDA:</b>\n` +
    `Username: <code>${credentials.username}</code>\n` +
    `Password: <code>${credentials.password}</code>\n\n` +
    `\u23f0 <b>MASA AKTIF:</b>\n` +
    `Berlaku hingga: <b>${expiryDate} WIB</b>\n\n` +
    `\ud83c\udf81 <b>REWARD POINT:</b>\n` +
    `Anda mendapatkan <b>${pointsEarned} points</b>\n` +
    `Total point Anda: <b>${userPoints} points</b>\n\n` +
    `\u2728 <b>Selamat bermain!</b> \ud83c\udfae\n\n` +
    `\ud83d\udcc1 <b>Untuk file dan tutorial instalasi:</b>\n` +
    `Klik tombol '\ud83d\udcc1 File & Cara Pasang' di bawah`;

  const keyboard = JSON.stringify({
    inline_keyboard: [
      [
        {
          text: "\ud83d\udcc1 File & Cara Pasang",
          url: "https://t.me/+RY2yMHn_jts3YzA1",
        },
      ],
      [
        { text: "\ud83d\udd04 Beli Lagi", callback_data: "new_order" },
        { text: "\ud83c\udf81 Tukar Point", callback_data: "redeem_points" },
      ],
      [{ text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" }],
    ],
  });

  const { WELCOME_IMAGE } = await import("./bot-config");
  const result = await sendPhoto(chatId, WELCOME_IMAGE, message, keyboard);

  // Notify admin
  const adminMsg =
    `\ud83d\udcb0 <b>PEMBELIAN BERHASIL!</b>\n\n` +
    `User ID: <code>${chatId}</code>\n` +
    `Jenis Game: <b>${gameName}</b>\n` +
    `Durasi: <b>${duration} Hari</b>\n` +
    `Tipe Key: <b>${keyType === "manual" ? "MANUAL" : "RANDOM"}</b>\n` +
    `Username: <code>${credentials.username}</code>\n` +
    `Password: <code>${credentials.password}</code>\n` +
    `Point Diberikan: <b>${pointsEarned} points</b>\n` +
    `Masa Aktif: <b>${expiryDate} WIB</b>\n` +
    `Waktu: ${formatDateWIB(new Date())}`;
  await notifyAdmin(adminMsg);

  return result;
}

async function sendExtendSuccess(
  chatId: string,
  userData: Record<string, string>,
  duration: number,
  newExpDate: string
) {
  const gameName =
    userData.game_type === "ff" ? "FREE FIRE" : "FREE FIRE MAX";
  const currentExp = formatDateFromDB(userData.expDate);

  const pointsEarned = calculatePointsForDuration(duration);
  await api.addUserPoints(
    chatId,
    pointsEarned,
    `Extend lisensi ${duration} hari`
  );
  const userPoints = await api.getUserPoints(chatId);

  const message =
    `\ud83c\udf89 <b>EXTEND BERHASIL!</b>\n\n` +
    `Akun Anda berhasil di-extend\n` +
    `Jenis: <b>${gameName}</b>\n` +
    `Username: <code>${userData.username}</code>\n` +
    `Durasi Tambahan: <b>${duration} Hari</b>\n` +
    `Masa Aktif Lama: <b>${currentExp} WIB</b>\n` +
    `Masa Aktif Baru: <b>${formatDateFromDB(newExpDate)} WIB</b>\n\n` +
    `\ud83c\udf81 <b>REWARD POINT:</b>\n` +
    `Anda mendapatkan <b>${pointsEarned} points</b>\n` +
    `Total point Anda: <b>${userPoints} points</b>\n\n` +
    `\u2728 <b>Selamat bermain!</b> \ud83c\udfae\n\n` +
    `\ud83d\udcc1 <b>Untuk file dan tutorial instalasi:</b>\n` +
    `Klik tombol '\ud83d\udcc1 File & Cara Pasang' di bawah`;

  const keyboard = JSON.stringify({
    inline_keyboard: [
      [
        {
          text: "\ud83d\udcc1 File & Cara Pasang",
          url: "https://t.me/+RY2yMHn_jts3YzA1",
        },
      ],
      [
        { text: "\ud83d\udd04 Extend Lagi", callback_data: "extend_user" },
        { text: "\ud83c\udf81 Tukar Point", callback_data: "redeem_points" },
      ],
      [{ text: "\ud83d\udd04 Beli Baru", callback_data: "new_order" }],
      [{ text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" }],
    ],
  });

  const { WELCOME_IMAGE } = await import("./bot-config");
  const result = await sendPhoto(chatId, WELCOME_IMAGE, message, keyboard);

  const adminMsg =
    `\u23f0 <b>EXTEND BERHASIL!</b>\n\n` +
    `User ID: <code>${chatId}</code>\n` +
    `Jenis Game: <b>${gameName}</b>\n` +
    `Username: <code>${userData.username}</code>\n` +
    `Durasi: <b>${duration} Hari</b>\n` +
    `Point Diberikan: <b>${pointsEarned} points</b>\n` +
    `Masa Aktif Baru: <b>${formatDateFromDB(newExpDate)} WIB</b>\n` +
    `Waktu: ${formatDateWIB(new Date())}`;
  await notifyAdmin(adminMsg);

  return result;
}

// ============================================================
// PROCESS SUCCESSFUL PAYMENT
// ============================================================

export async function processSuccessfulPayment(
  chatId: string,
  qrMessageId: number,
  order: Record<string, string>
) {
  if (order.key_type === "extend") {
    const extendResult = await api.extendLicense(
      order.manual_username,
      order.manual_password,
      parseInt(order.duration),
      order.game_type
    );

    if (extendResult.success) {
      const userData = await api.getUser(
        order.manual_username,
        order.manual_password,
        order.game_type
      );
      if (userData) {
        await sendExtendSuccess(
          chatId,
          userData,
          parseInt(order.duration),
          extendResult.new_exp_date
        );
        await api.updateOrderStatus(order.deposit_code, "completed");
      }
    }
  } else {
    let credentials: { username: string; password: string };
    if (order.key_type === "manual") {
      credentials = {
        username: order.manual_username,
        password: order.manual_password,
      };
    } else {
      credentials = generateRandomCredentials();
    }

    const table = order.game_type === "ff" ? "freefire" : "ffmax";
    const saved = await api.saveLicense(
      table,
      credentials.username,
      credentials.password,
      parseInt(order.duration),
      MERCHANT_CODE
    );

    if (saved) {
      await sendLicenseToUser(
        chatId,
        order.game_type,
        parseInt(order.duration),
        credentials,
        order.key_type
      );
      await api.updateOrderStatus(order.deposit_code, "completed");
    }
  }
}

// ============================================================
// HANDLE /start COMMAND
// ============================================================

export async function handleStart(
  chatId: string,
  firstName: string,
  username: string
) {
  await api.clearUserState(chatId);
  await api.saveBotUser(chatId, firstName, username);

  const userPoints = await api.getUserPoints(chatId);

  const welcomeMessage =
    `\ud83c\udfae <b>Selamat Datang, ${firstName}!</b>\n\n` +
    `\u2728 <b>BOT PEMBELIAN LISENSI FREE FIRE</b> \u2728\n\n` +
    `\ud83d\udcb0 <b>Point Anda:</b> ${userPoints} points\n\n` +
    `\ud83d\uded2 <b>Fitur yang tersedia:</b>\n` +
    `\u2022 Beli lisensi baru (Random/Manual)\n` +
    `\u2022 Extend masa aktif akun\n` +
    `\u2022 Tukar point dengan lisensi gratis\n` +
    `\u2022 Support Free Fire & Free Fire MAX\n` +
    `\u2022 Pembayaran QRIS otomatis\n\n` +
    `\ud83d\udcb0 <b>Harga mulai dari Rp 15.000</b>\n` +
    `\ud83c\udf81 <b>Dapatkan point untuk setiap pembelian!</b>\n\n` +
    `\u23f0 <b>Pembayaran otomatis terdeteksi dalam 25 menit!</b>\n\n` +
    `Silakan pilih menu di bawah:`;

  const keyboard = JSON.stringify({
    inline_keyboard: [
      [{ text: "\ud83d\uded2 Beli Lisensi Baru", callback_data: "new_order" }],
      [
        {
          text: "\u23f0 Extend Masa Aktif",
          callback_data: "extend_user",
        },
        { text: "\ud83c\udf81 Tukar Point", callback_data: "redeem_points" },
      ],
      [{ text: "\u2139\ufe0f Bantuan", callback_data: "help" }],
    ],
  });

  return sendMessageWithImage(chatId, welcomeMessage, keyboard);
}

// ============================================================
// HANDLE /menu COMMAND
// ============================================================

export async function handleMenu(chatId: string) {
  return showMainMenu(
    chatId,
    "\ud83c\udfe0 <b>Menu Utama</b>\n\nSilakan pilih menu yang diinginkan:"
  );
}

// ============================================================
// HANDLE /points COMMAND
// ============================================================

export async function handlePoints(chatId: string) {
  const userPoints = await api.getUserPoints(chatId);

  const message =
    `\ud83d\udcb0 <b>POINT ANDA</b>\n\n` +
    `Total Point: <b>${userPoints} points</b>\n\n` +
    `\ud83d\udcca <b>Cara mendapatkan point:</b>\n` +
    `\u2022 Beli lisensi 1 hari = 1 point\n` +
    `\u2022 Beli lisensi 3 hari = 2 point\n` +
    `\u2022 Beli lisensi 5 hari = 4 point\n` +
    `\u2022 Beli lisensi 7 hari = 5 point\n` +
    `\u2022 Dan seterusnya...\n\n` +
    `\ud83c\udf81 <b>Tukar point dengan lisensi gratis!</b>\n` +
    `12 points = 1 hari lisensi gratis`;

  const keyboard = JSON.stringify({
    inline_keyboard: [
      [{ text: "\ud83c\udf81 Tukar Point", callback_data: "redeem_points" }],
      [{ text: "\ud83d\uded2 Beli Lisensi", callback_data: "new_order" }],
      [{ text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" }],
    ],
  });

  return sendMessageWithImage(chatId, message, keyboard);
}

// ============================================================
// HANDLE BROADCAST COMMANDS
// ============================================================

export async function handleBroadcastCommand(
  chatId: string,
  type: "pengumuman" | "adds"
) {
  if (!isAdmin(chatId)) {
    await sendMessage(
      chatId,
      "\u274c <b>Akses Ditolak!</b>\n\nPerintah ini hanya untuk admin."
    );
    return;
  }

  const totalUsers = await api.getTotalBotUsers();
  const label =
    type === "pengumuman" ? "PENGUMUMAN" : "NOTIFIKASI/IKLAN";
  const emoji = type === "pengumuman" ? "\ud83d\udce2" : "\ud83d\udd14";

  const message =
    `${emoji} <b>MODE ${label}</b>\n\n` +
    `Kirim pesan yang ingin Anda broadcast ke semua pengguna.\n\n` +
    `\ud83d\udcca <b>Total Pengguna Aktif:</b> ${totalUsers} users\n\n` +
    `\u2705 <b>Anda dapat mengirim:</b>\n` +
    `\u2022 Foto dengan caption\n` +
    `\u2022 Video dengan caption\n` +
    `\u2022 File/Dokumen dengan caption\n` +
    `\u2022 Pesan teks biasa\n\n` +
    `\u26a0\ufe0f <b>Kirim /cancel untuk membatalkan</b>`;

  await api.saveAdminState(chatId, `waiting_broadcast_${type}`);
  await sendMessage(chatId, message);
}

export async function handleCancelBroadcast(chatId: string) {
  const adminState = await api.getAdminState(chatId);
  if (adminState && adminState.state.startsWith("waiting_broadcast")) {
    await api.clearAdminState(chatId);
    await sendMessage(chatId, "\u2705 <b>Broadcast dibatalkan.</b>");
  }
}

// ============================================================
// HANDLE BROADCAST CONTENT
// ============================================================

export async function handleBroadcastContent(
  chatId: string,
  update: Record<string, unknown>
): Promise<boolean> {
  const adminState = await api.getAdminState(chatId);
  if (
    !adminState ||
    !adminState.state.startsWith("waiting_broadcast")
  ) {
    return false;
  }

  const broadcastType = adminState.state.replace("waiting_broadcast_", "");
  const msg = update.message as Record<string, unknown>;

  let messageType = "";
  let fileId = "";
  let caption = "";

  if (msg.photo) {
    messageType = "photo";
    const photos = msg.photo as Array<{ file_id: string }>;
    fileId = photos[photos.length - 1].file_id;
    caption = (msg.caption as string) || "";
  } else if (msg.video) {
    messageType = "video";
    fileId = (msg.video as { file_id: string }).file_id;
    caption = (msg.caption as string) || "";
  } else if (msg.document) {
    messageType = "document";
    fileId = (msg.document as { file_id: string }).file_id;
    caption = (msg.caption as string) || "";
  } else if (msg.audio) {
    messageType = "audio";
    fileId = (msg.audio as { file_id: string }).file_id;
    caption = (msg.caption as string) || "";
  } else if (msg.text) {
    messageType = "text";
    caption = msg.text as string;
  }

  if (!messageType) return false;

  // Confirm
  const label =
    broadcastType === "pengumuman" ? "Pengumuman" : "Notifikasi/Iklan";
  const confirmMessage =
    `\ud83d\udce4 <b>KONFIRMASI BROADCAST</b>\n\n` +
    `Tipe: <b>${label}</b>\n` +
    `Format: <b>${messageType.toUpperCase()}</b>\n` +
    (caption
      ? `Caption: ${caption.substring(0, 100)}${caption.length > 100 ? "..." : ""}\n`
      : "") +
    `\n\u23f3 <b>Memulai broadcast...</b>`;

  await sendMessage(chatId, confirmMessage);

  // Broadcast
  const allUsers = await api.getAllBotUsers();
  let success = 0;
  let failed = 0;

  for (const userId of allUsers) {
    try {
      const result = await sendBroadcastMessage(
        userId,
        messageType,
        fileId,
        caption
      );
      if (result?.ok) {
        success++;
      } else {
        failed++;
      }
    } catch {
      failed++;
    }
  }

  await api.saveBroadcastHistory({
    adminChatId: chatId,
    broadcastType,
    messageType,
    totalUsers: allUsers.length,
    successCount: success,
    failedCount: failed,
  });

  await api.clearAdminState(chatId);

  const successRate =
    allUsers.length > 0
      ? ((success / allUsers.length) * 100).toFixed(2)
      : "0";

  const resultMessage =
    `\u2705 <b>BROADCAST SELESAI!</b>\n\n` +
    `\ud83d\udcca <b>Statistik:</b>\n` +
    `\u2022 Total Pengguna: ${allUsers.length}\n` +
    `\u2022 Berhasil: ${success} \u2705\n` +
    `\u2022 Gagal: ${failed} \u274c\n` +
    `\u2022 Success Rate: ${successRate}%\n\n` +
    `Waktu: ${formatDateWIB(new Date())}`;

  await sendMessage(chatId, resultMessage);
  return true;
}

// ============================================================
// HANDLE TEXT MESSAGES (manual input, etc.)
// ============================================================

export async function handleTextMessage(
  chatId: string,
  text: string,
  firstName: string,
  username: string
) {
  // /start
  if (text.startsWith("/start")) {
    return handleStart(chatId, firstName, username);
  }

  // /menu
  if (text.startsWith("/menu")) {
    return handleMenu(chatId);
  }

  // /points
  if (text.startsWith("/points")) {
    return handlePoints(chatId);
  }

  // /pengumuman
  if (text.startsWith("/pengumuman")) {
    return handleBroadcastCommand(chatId, "pengumuman");
  }

  // /adds
  if (text.startsWith("/adds")) {
    return handleBroadcastCommand(chatId, "adds");
  }

  // /cancel
  if (text.startsWith("/cancel")) {
    return handleCancelBroadcast(chatId);
  }

  // State-based input
  const userState = await api.getUserState(chatId);

  if (userState && userState.state === "waiting_manual_input") {
    return handleManualInput(chatId, text, userState);
  }

  if (userState && userState.state === "waiting_extend_credentials") {
    return handleExtendCredentials(chatId, text, userState);
  }
}

// ============================================================
// HANDLE MANUAL KEY INPUT
// ============================================================

async function handleManualInput(
  chatId: string,
  text: string,
  userState: { state: string; data: Record<string, unknown>; error_count: number }
) {
  if (!text.startsWith("/")) {
    return sendMessageWithImage(
      chatId,
      "\u274c <b>Gunakan format command!</b>\n\nFormat: <code>/username-password</code>\nContoh: <code>/kambing-1</code>",
      getBackButton("new_order")
    );
  }

  const input = text.substring(1);
  const dashIndex = input.indexOf("-");

  if (dashIndex === -1) {
    return sendMessageWithImage(
      chatId,
      "\u274c <b>Format tidak valid!</b>\n\nFormat: <code>/username-password</code>\nContoh: <code>/kambing-1</code>",
      getBackButton("new_order")
    );
  }

  const username = input.substring(0, dashIndex).trim();
  const password = input.substring(dashIndex + 1).trim();

  if (!username || !password) {
    return sendMessageWithImage(
      chatId,
      "\u274c <b>Username dan password tidak boleh kosong!</b>\n\nFormat: <code>/username-password</code>\nContoh: <code>/kambing-1</code>",
      getBackButton("new_order")
    );
  }

  const gameType = userState.data.game_type as string;
  const table = gameType === "ff" ? "freefire" : "ffmax";
  const exists = await api.checkUsername(username, table);

  if (exists) {
    const gameName = gameType === "ff" ? "FREE FIRE" : "FREE FIRE MAX";
    return sendMessageWithImage(
      chatId,
      `\u274c <b>Username sudah digunakan di ${gameName}!</b>\n\n` +
        `Username <code>${username}</code> sudah terdaftar di <b>${gameName}</b>.\n\n` +
        `\ud83d\udca1 <b>Tips:</b> Gunakan username yang berbeda\n\n` +
        `\ud83d\udcdd <b>Format:</b> <code>/username-password</code>\n` +
        `\ud83c\udfaf <b>Contoh:</b> <code>/player123-1</code>`,
      getBackButton("new_order")
    );
  }

  const duration = userState.data.duration as string;
  const amount = PRICES[duration];
  const orderId = "DIMZ" + Date.now() + Math.floor(Math.random() * 900 + 100);

  const payment = await api.createPayment(orderId, amount);

  if (payment && payment.status) {
    const paymentData = payment.data;
    const gameName = gameType.toUpperCase();

    const message =
      `\ud83d\udcb3 <b>PEMBAYARAN ${gameName} (MANUAL)</b>\n\n` +
      `Jenis: <b>${gameName}</b>\n` +
      `Durasi: <b>${duration} Hari</b>\n` +
      `Tipe: <b>KEY MANUAL</b>\n` +
      `Username: <code>${username}</code>\n` +
      `Password: <code>${password}</code>\n` +
      `Harga: <b>Rp ${formatPrice(amount)}</b>\n` +
      `Order ID: <code>${orderId}</code>\n\n` +
      `\ud83d\udcf1 <b>INSTRUKSI PEMBAYARAN:</b>\n` +
      `1. Scan QR Code di bawah\n` +
      `2. Bayar sesuai amount\n` +
      `3. Pembayaran akan terdeteksi otomatis\n\n` +
      `\u23f0 <b>Batas Waktu: 25 MENIT</b>\n` +
      `\ud83d\udd04 <b>Cek Otomatis: Setiap 20 detik</b>\n` +
      `QR akan otomatis terhapus setelah 25 menit jika tidak bayar\n` +
      `Expired: ${paymentData.expired}\n\n` +
      `\ud83d\ude80 <b>Pembayaran akan diproses otomatis!</b>`;

    const keyboard = JSON.stringify({
      inline_keyboard: [
        [
          {
            text: "\ud83d\udd0d Cek Status Manual",
            callback_data: "check_payment",
          },
        ],
        [
          {
            text: "\u274c Batalkan Pesanan",
            callback_data: "cancel_order",
          },
        ],
      ],
    });

    await api.savePendingOrder({
      orderId,
      chatId,
      gameType,
      duration: parseInt(duration),
      amount,
      depositCode: paymentData.kode_deposit,
      keyType: "manual",
      manualUsername: username,
      manualPassword: password,
    });
    await api.clearUserState(chatId);

    const result = await sendPhoto(
      chatId,
      paymentData.link_qr,
      message,
      keyboard
    );

    // Schedule auto-delete and payment check
    if (result?.ok) {
      const msgId = result.result.message_id;
      const now = Math.floor(Date.now() / 1000);
      await api.savePaymentCheck(
        chatId,
        String(msgId),
        now,
        now + ORDER_TIMEOUT
      );
      await api.saveMessageSchedule(
        chatId,
        String(msgId),
        ORDER_TIMEOUT,
        "pending"
      );
    }
  } else {
    await sendMessageWithImage(
      chatId,
      "\u274c Gagal membuat pembayaran. Silakan coba lagi.",
      getBackButton("new_order")
    );
    await api.clearUserState(chatId);
  }
}

// ============================================================
// HANDLE EXTEND CREDENTIALS INPUT
// ============================================================

async function handleExtendCredentials(
  chatId: string,
  text: string,
  userState: { state: string; data: Record<string, unknown>; error_count: number }
) {
  if (!text.startsWith("/")) {
    return sendMessageWithImage(
      chatId,
      "\u274c <b>Gunakan format command!</b>\n\nFormat: <code>/username-password</code>\nContoh: <code>/kambing-1</code>",
      getBackButton("extend_user")
    );
  }

  const input = text.substring(1);
  const dashIndex = input.indexOf("-");

  if (dashIndex === -1) {
    return sendMessageWithImage(
      chatId,
      "\u274c <b>Format tidak valid!</b>\n\nFormat: <code>/username-password</code>\nContoh: <code>/kambing-1</code>",
      getBackButton("extend_user")
    );
  }

  const username = input.substring(0, dashIndex).trim();
  const password = input.substring(dashIndex + 1).trim();
  const gameType = userState.data.game_type as string;

  const userData = await api.getUser(username, password, gameType);

  if (userData) {
    await api.updateErrorCount(chatId, 0);

    await api.saveUserState(chatId, "waiting_extend_duration", {
      username,
      password,
      user_data: userData,
      game_type: gameType,
    });

    const gameName = gameType === "ff" ? "FREE FIRE" : "FREE FIRE MAX";
    const currentExp = formatDateFromDB(userData.expDate);

    const message =
      `\u2705 <b>USERNAME DAN PASSWORD COCOK!</b>\n\n` +
      `Username: <code>${username}</code>\n` +
      `Jenis: <b>${gameName}</b>\n` +
      `Masa Aktif Saat Ini: <b>${currentExp} WIB</b>\n\n` +
      `\ud83d\udcb0 <b>Pilih Durasi Extend:</b>`;

    const keyboard = JSON.stringify({
      inline_keyboard: [
        [
          { text: "1 Hari - 15k", callback_data: "extend_duration_1" },
          { text: "2 Hari - 30k", callback_data: "extend_duration_2" },
          { text: "3 Hari - 40k", callback_data: "extend_duration_3" },
        ],
        [
          { text: "4 Hari - 50k", callback_data: "extend_duration_4" },
          { text: "5 Hari - 60k", callback_data: "extend_duration_5" },
          { text: "6 Hari - 70k", callback_data: "extend_duration_6" },
        ],
        [
          { text: "7 Hari - 80k", callback_data: "extend_duration_7" },
          { text: "8 Hari - 90k", callback_data: "extend_duration_8" },
          {
            text: "10 Hari - 100k",
            callback_data: "extend_duration_10",
          },
        ],
        [
          {
            text: "15 Hari - 150k",
            callback_data: "extend_duration_15",
          },
          {
            text: "20 Hari - 180k",
            callback_data: "extend_duration_20",
          },
          {
            text: "30 Hari - 250k",
            callback_data: "extend_duration_30",
          },
        ],
        [
          {
            text: "\u21a9\ufe0f Kembali",
            callback_data: "extend_type_" + gameType,
          },
          { text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" },
        ],
      ],
    });

    return sendMessageWithImage(chatId, message, keyboard);
  } else {
    const currentErrorCount = userState.error_count || 0;
    const newErrorCount = currentErrorCount + 1;
    await api.updateErrorCount(chatId, newErrorCount);

    const gameName = gameType === "ff" ? "FREE FIRE" : "FREE FIRE MAX";
    let errorMessage = `\u274c <b>Username dan Password tidak cocok di ${gameName}!</b>\n\n`;

    if (newErrorCount >= 2) {
      errorMessage += `\u26a0\ufe0f <b>Anda telah 2 kali melakukan kesalahan.</b>\nSilakan mulai ulang dari menu utama.\n\n`;
      await api.clearUserState(chatId);
      return sendMessageWithImage(chatId, errorMessage, getBackButton());
    } else {
      errorMessage += `Silakan coba lagi dengan username dan password yang benar:\n\nFormat: <code>/username-password</code>\nContoh: <code>/kambing-1</code>`;
      return sendMessageWithImage(
        chatId,
        errorMessage,
        getBackButton("extend_user")
      );
    }
  }
}

// ============================================================
// HANDLE CALLBACK QUERIES
// ============================================================

export async function handleCallback(
  update: Record<string, unknown>
) {
  const callback = update.callback_query as Record<string, unknown>;
  const data = callback.data as string;
  const cbMsg = callback.message as Record<string, unknown>;
  const chat = cbMsg.chat as Record<string, unknown>;
  const chatId = String(chat.id);
  const messageId = cbMsg.message_id as number;
  const callbackId = callback.id as string;

  try {
    await answerCallbackQuery(callbackId);

    // MAIN MENU
    if (data === "main_menu") {
      await api.clearUserState(chatId);
      return showMainMenu(chatId, null, messageId);
    }

    // NEW ORDER
    if (data === "new_order") {
      const message =
        "\ud83d\udc4b <b>Halo!</b>\n\nSilakan pilih jenis Free Fire yang ingin Anda beli:";
      const keyboard = JSON.stringify({
        inline_keyboard: [
          [
            { text: "\ud83c\udfae FREE FIRE", callback_data: "type_ff" },
            {
              text: "\u26a1 FREE FIRE MAX",
              callback_data: "type_ffmax",
            },
          ],
          [
            {
              text: "\u21a9\ufe0f Kembali",
              callback_data: "main_menu",
            },
          ],
        ],
      });
      return editMessageSmart(chatId, messageId, message, keyboard);
    }

    // EXTEND USER
    if (data === "extend_user") {
      const message =
        "\ud83c\udfae <b>EXTEND MASA AKTIF</b>\n\nPilih jenis Free Fire yang ingin di-extend:";
      const keyboard = JSON.stringify({
        inline_keyboard: [
          [
            {
              text: "\ud83c\udfae FREE FIRE",
              callback_data: "extend_type_ff",
            },
            {
              text: "\u26a1 FREE FIRE MAX",
              callback_data: "extend_type_ffmax",
            },
          ],
          [
            {
              text: "\u21a9\ufe0f Kembali",
              callback_data: "main_menu",
            },
          ],
        ],
      });
      return editMessageSmart(chatId, messageId, message, keyboard);
    }

    // REDEEM POINTS
    if (data === "redeem_points") {
      return showRedeemPointsMenu(chatId, messageId);
    }

    // HELP
    if (data === "help") {
      const userPoints = await api.getUserPoints(chatId);
      const helpMessage =
        `\u2139\ufe0f <b>BANTUAN</b>\n\n` +
        `\ud83d\udcb0 <b>Point Anda:</b> ${userPoints} points\n\n` +
        `\ud83d\udcdd <b>Cara Penggunaan:</b>\n` +
        `1. Pilih 'Beli Lisensi Baru' untuk pembelian baru\n` +
        `2. Pilih 'Extend Masa Aktif' untuk memperpanjang\n` +
        `3. Pilih 'Tukar Point' untuk lisensi gratis\n` +
        `4. Ikuti instruksi yang diberikan\n\n` +
        `\ud83d\udd27 <b>Fitur:</b>\n` +
        `\u2022 Support Free Fire & Free Fire MAX\n` +
        `\u2022 Pembayaran QRIS otomatis\n` +
        `\u2022 Extend masa aktif\n` +
        `\u2022 Key random & manual\n` +
        `\u2022 Sistem point/reward\n\n` +
        `\ud83c\udf81 <b>Sistem Point:</b>\n` +
        `\u2022 Dapatkan point dari setiap pembelian\n` +
        `\u2022 12 points = 1 hari lisensi gratis\n` +
        `\u2022 Point tidak memiliki masa kedaluwarsa\n\n` +
        `\u23f0 <b>Pembayaran Otomatis:</b>\n` +
        `\u2022 QR berlaku selama 25 menit\n` +
        `\u2022 Cek pembayaran otomatis setiap 20 detik\n` +
        `\u2022 QR terhapus otomatis jika tidak dibayar\n` +
        `\u2022 Pesan sukses tidak akan dihapus\n\n` +
        `\u2753 <b>Pertanyaan?</b>\n` +
        `Hubungi admin jika ada kendala @dimasvip1120`;

      return showMainMenu(chatId, helpMessage, messageId);
    }

    // TYPE SELECTION (type_ff, type_ffmax)
    if (data.startsWith("type_")) {
      const type = data.replace("type_", "");
      const message = `\ud83d\udcb0 <b>Pilih Durasi Lisensi ${type.toUpperCase()}:</b>\n\nSilakan pilih durasi:`;
      const keyboard = JSON.stringify({
        inline_keyboard: [
          [
            { text: "1 Hari - 15k", callback_data: `duration_${type}_1` },
            { text: "2 Hari - 30k", callback_data: `duration_${type}_2` },
            { text: "3 Hari - 40k", callback_data: `duration_${type}_3` },
          ],
          [
            { text: "4 Hari - 50k", callback_data: `duration_${type}_4` },
            { text: "5 Hari - 60k", callback_data: `duration_${type}_5` },
            { text: "6 Hari - 70k", callback_data: `duration_${type}_6` },
          ],
          [
            { text: "7 Hari - 80k", callback_data: `duration_${type}_7` },
            { text: "8 Hari - 90k", callback_data: `duration_${type}_8` },
            {
              text: "10 Hari - 100k",
              callback_data: `duration_${type}_10`,
            },
          ],
          [
            {
              text: "15 Hari - 150k",
              callback_data: `duration_${type}_15`,
            },
            {
              text: "20 Hari - 180k",
              callback_data: `duration_${type}_20`,
            },
            {
              text: "30 Hari - 250k",
              callback_data: `duration_${type}_30`,
            },
          ],
          [
            { text: "\u21a9\ufe0f Kembali", callback_data: "new_order" },
            { text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" },
          ],
        ],
      });
      return editMessageSmart(chatId, messageId, message, keyboard);
    }

    // DURATION SELECTION (duration_ff_1, etc.)
    if (data.startsWith("duration_")) {
      const parts = data.split("_");
      const type = parts[1];
      const duration = parts[2];

      const message =
        `\ud83d\udd11 <b>Pilih Tipe Key untuk ${type.toUpperCase()}:</b>\n\n` +
        `\ud83c\udfb2 <b>RANDOM KEY</b>\n` +
        `\u2022 Username & password digenerate otomatis\n` +
        `\u2022 Format: 2 huruf + 2 angka (Username), 2 angka (Password)\n\n` +
        `\u270f\ufe0f <b>MANUAL KEY</b>\n` +
        `\u2022 Input username & password manual\n` +
        `\u2022 Format: <code>/username-password</code>\n\n` +
        `Silakan pilih tipe key:`;

      const keyboard = JSON.stringify({
        inline_keyboard: [
          [
            {
              text: "\ud83c\udfb2 RANDOM KEY",
              callback_data: `keytype_${type}_${duration}_random`,
            },
            {
              text: "\u270f\ufe0f MANUAL KEY",
              callback_data: `keytype_${type}_${duration}_manual`,
            },
          ],
          [
            {
              text: "\u21a9\ufe0f Kembali",
              callback_data: "type_" + type,
            },
            { text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" },
          ],
        ],
      });
      return editMessageSmart(chatId, messageId, message, keyboard);
    }

    // KEY TYPE SELECTION (keytype_ff_1_random, etc.)
    if (data.startsWith("keytype_")) {
      const parts = data.split("_");
      const type = parts[1];
      const duration = parts[2];
      const keyType = parts[3];

      if (keyType === "random") {
        return handleRandomKeyOrder(chatId, type, duration);
      } else if (keyType === "manual") {
        await api.saveUserState(chatId, "waiting_manual_input", {
          game_type: type,
          duration,
        });

        const instruction =
          `\u270f\ufe0f <b>MASUKKAN USERNAME & PASSWORD</b>\n\n` +
          `\ud83d\udcdd <b>Gunakan format:</b>\n` +
          `<code>/username-password</code>\n\n` +
          `\ud83c\udfaf <b>Contoh:</b>\n` +
          `<code>/kambing-1</code>\n` +
          `<code>/player-123</code>\n` +
          `<code>/gamer-99</code>\n\n` +
          `\u27a1\ufe0f <b>Username</b> sebelum tanda minus (-)\n` +
          `\u27a1\ufe0f <b>Password</b> setelah tanda minus (-)`;

        const keyboard = JSON.stringify({
          inline_keyboard: [
            [
              {
                text: "\u21a9\ufe0f Kembali",
                callback_data: `duration_${type}_${duration}`,
              },
              {
                text: "\ud83c\udfe0 Menu Utama",
                callback_data: "main_menu",
              },
            ],
          ],
        });

        return editMessageSmart(chatId, messageId, instruction, keyboard);
      }
    }

    // EXTEND TYPE SELECTION (extend_type_ff, extend_type_ffmax)
    if (data.startsWith("extend_type_")) {
      const gameType = data.replace("extend_type_", "");
      const gameName = gameType === "ff" ? "FREE FIRE" : "FREE FIRE MAX";

      await api.saveUserState(chatId, "waiting_extend_credentials", {
        game_type: gameType,
      });

      const message =
        `\u270f\ufe0f <b>EXTEND ${gameName}</b>\n\n` +
        `Masukkan <b>USERNAME dan PASSWORD</b> yang ingin di-extend:\n\n` +
        `\ud83d\udcdd <b>Format:</b>\n` +
        `<code>/username-password</code>\n\n` +
        `\ud83c\udfaf <b>Contoh:</b>\n` +
        `<code>/kambing-1</code>\n` +
        `<code>/player-123</code>\n\n` +
        `\u26a0\ufe0f <b>Pastikan username dan password terdaftar di ${gameName}</b>`;

      const keyboard = JSON.stringify({
        inline_keyboard: [
          [
            {
              text: "\u21a9\ufe0f Kembali",
              callback_data: "extend_user",
            },
            { text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" },
          ],
        ],
      });

      return editMessageSmart(chatId, messageId, message, keyboard);
    }

    // EXTEND DURATION SELECTION (extend_duration_1, etc.)
    if (data.startsWith("extend_duration_")) {
      const duration = data.replace("extend_duration_", "");
      const userState = await api.getUserState(chatId);

      if (userState && userState.state === "waiting_extend_duration") {
        return handleExtendPayment(chatId, duration, userState);
      }
    }

    // REDEEM DURATION SELECTION (redeem_1, redeem_2, etc.)
    if (data.startsWith("redeem_") && !isNaN(Number(data.replace("redeem_", "")))) {
      const duration = parseInt(data.replace("redeem_", ""));
      return processPointRedemption(chatId, duration, messageId);
    }

    // REDEEM GAME TYPE (redeem_ff, redeem_ffmax)
    if (data === "redeem_ff" || data === "redeem_ffmax") {
      const gameType = data === "redeem_ff" ? "ff" : "ffmax";
      const userState = await api.getUserState(chatId);

      if (userState && userState.state === "waiting_redeem_game") {
        const duration = userState.data.duration as number;
        await completePointRedemption(chatId, gameType, duration, messageId);
        await api.clearUserState(chatId);
      } else {
        await editMessageSmart(
          chatId,
          messageId,
          "\u274c <b>Sesi telah berakhir!</b>\n\nSilakan mulai ulang dari menu penukaran point.",
          getBackButton("redeem_points")
        );
      }
      return;
    }

    // CHECK PAYMENT
    if (data === "check_payment") {
      return handleCheckPayment(chatId, messageId, "new_order");
    }

    // CHECK EXTEND
    if (data === "check_extend") {
      return handleCheckPayment(chatId, messageId, "extend_user");
    }

    // CANCEL ORDER
    if (data === "cancel_order") {
      const order = await api.getPendingOrder(chatId);
      if (order) {
        await api.updateOrderStatus(order.deposit_code, "cancelled");
      }
      await api.clearUserState(chatId);
      return editMessageSmart(
        chatId,
        messageId,
        "\u274c Pesanan dibatalkan.",
        getBackButton()
      );
    }
  } catch (e) {
    console.error("Callback error:", e);
    await sendMessageWithImage(
      chatId,
      "\u274c <b>Terjadi kesalahan!</b>\n\nSilakan coba lagi atau gunakan menu /start",
      getBackButton()
    );
  }
}

// ============================================================
// RANDOM KEY ORDER
// ============================================================

async function handleRandomKeyOrder(
  chatId: string,
  type: string,
  duration: string
) {
  const amount = PRICES[duration];
  const orderId = "DIMZ" + Date.now() + Math.floor(Math.random() * 900 + 100);

  const payment = await api.createPayment(orderId, amount);

  if (payment && payment.status) {
    const paymentData = payment.data;

    const message =
      `\ud83d\udcb3 <b>PEMBAYARAN ${type.toUpperCase()} (RANDOM)</b>\n\n` +
      `Jenis: <b>${type.toUpperCase()}</b>\n` +
      `Durasi: <b>${duration} Hari</b>\n` +
      `Tipe: <b>KEY RANDOM</b>\n` +
      `Harga: <b>Rp ${formatPrice(amount)}</b>\n` +
      `Order ID: <code>${orderId}</code>\n\n` +
      `\ud83d\udcf1 <b>INSTRUKSI PEMBAYARAN:</b>\n` +
      `1. Scan QR Code di bawah\n` +
      `2. Bayar sesuai amount\n` +
      `3. Pembayaran akan terdeteksi otomatis\n\n` +
      `\u23f0 <b>Batas Waktu: 25 MENIT</b>\n` +
      `\ud83d\udd04 <b>Cek Otomatis: Setiap 20 detik</b>\n` +
      `QR akan otomatis terhapus setelah 25 menit jika tidak bayar\n` +
      `Expired: ${paymentData.expired}\n\n` +
      `\ud83d\ude80 <b>Pembayaran akan diproses otomatis!</b>`;

    const keyboard = JSON.stringify({
      inline_keyboard: [
        [
          {
            text: "\ud83d\udd0d Cek Status Manual",
            callback_data: "check_payment",
          },
        ],
        [
          {
            text: "\u274c Batalkan Pesanan",
            callback_data: "cancel_order",
          },
        ],
      ],
    });

    await api.savePendingOrder({
      orderId,
      chatId,
      gameType: type,
      duration: parseInt(duration),
      amount,
      depositCode: paymentData.kode_deposit,
      keyType: "random",
    });

    const result = await sendPhoto(
      chatId,
      paymentData.link_qr,
      message,
      keyboard
    );

    if (result?.ok) {
      const msgId = result.result.message_id;
      const now = Math.floor(Date.now() / 1000);
      await api.savePaymentCheck(
        chatId,
        String(msgId),
        now,
        now + ORDER_TIMEOUT
      );
      await api.saveMessageSchedule(
        chatId,
        String(msgId),
        ORDER_TIMEOUT,
        "pending"
      );
    }
  } else {
    await sendMessageWithImage(
      chatId,
      "\u274c Gagal membuat pembayaran. Silakan coba lagi.",
      getBackButton("type_" + type)
    );
  }
}

// ============================================================
// EXTEND PAYMENT
// ============================================================

async function handleExtendPayment(
  chatId: string,
  duration: string,
  userState: { state: string; data: Record<string, unknown> }
) {
  const username = userState.data.username as string;
  const password = userState.data.password as string;
  const userData = userState.data.user_data as Record<string, string>;
  const gameType = userState.data.game_type as string;
  const amount = PRICES[duration];
  const orderId = "EXTEND" + Date.now() + Math.floor(Math.random() * 900 + 100);

  const payment = await api.createPayment(orderId, amount);

  if (payment && payment.status) {
    const paymentData = payment.data;
    const gameName = gameType === "ff" ? "FREE FIRE" : "FREE FIRE MAX";
    const currentExp = formatDateFromDB(userData.expDate);
    const newExpDate = calculateNewExpDate(userData.expDate, parseInt(duration));

    const message =
      `\ud83d\udcb3 <b>EXTEND ${gameName}</b>\n\n` +
      `Username: <code>${username}</code>\n` +
      `Password: <code>${password}</code>\n` +
      `Jenis: <b>${gameName}</b>\n` +
      `Durasi: <b>${duration} Hari</b>\n` +
      `Harga: <b>Rp ${formatPrice(amount)}</b>\n` +
      `Masa Aktif Saat Ini: <b>${currentExp} WIB</b>\n` +
      `Masa Aktif Baru: <b>${newExpDate} WIB</b>\n` +
      `Order ID: <code>${orderId}</code>\n\n` +
      `\ud83d\udcf1 <b>INSTRUKSI PEMBAYARAN:</b>\n` +
      `1. Scan QR Code di bawah\n` +
      `2. Bayar sesuai amount\n` +
      `3. Pembayaran akan terdeteksi otomatis\n\n` +
      `\u23f0 <b>Batas Waktu: 25 MENIT</b>\n` +
      `\ud83d\udd04 <b>Cek Otomatis: Setiap 20 detik</b>\n` +
      `QR akan otomatis terhapus setelah 25 menit jika tidak bayar\n` +
      `Expired: ${paymentData.expired}\n\n` +
      `\ud83d\ude80 <b>Pembayaran akan diproses otomatis!</b>`;

    const keyboard = JSON.stringify({
      inline_keyboard: [
        [
          {
            text: "\ud83d\udd0d Cek Status Manual",
            callback_data: "check_extend",
          },
        ],
        [
          {
            text: "\u274c Batalkan Pesanan",
            callback_data: "cancel_order",
          },
        ],
      ],
    });

    await api.savePendingOrder({
      orderId,
      chatId,
      gameType,
      duration: parseInt(duration),
      amount,
      depositCode: paymentData.kode_deposit,
      keyType: "extend",
      manualUsername: username,
      manualPassword: password,
    });
    await api.clearUserState(chatId);

    const result = await sendPhoto(
      chatId,
      paymentData.link_qr,
      message,
      keyboard
    );

    if (result?.ok) {
      const msgId = result.result.message_id;
      const now = Math.floor(Date.now() / 1000);
      await api.savePaymentCheck(
        chatId,
        String(msgId),
        now,
        now + ORDER_TIMEOUT
      );
      await api.saveMessageSchedule(
        chatId,
        String(msgId),
        ORDER_TIMEOUT,
        "pending"
      );
    }
  } else {
    await editMessageSmart(
      chatId,
      0,
      "\u274c Gagal membuat pembayaran extend. Silakan coba lagi.",
      getBackButton("extend_user")
    );
    await api.clearUserState(chatId);
  }
}

// ============================================================
// CHECK PAYMENT STATUS
// ============================================================

async function handleCheckPayment(
  chatId: string,
  messageId: number,
  backAction: string
) {
  const order = await api.getPendingOrder(chatId);

  if (!order) {
    return editMessageSmart(
      chatId,
      messageId,
      "\u274c Tidak ada pesanan pending ditemukan.",
      getBackButton(backAction)
    );
  }

  const orderTime = new Date(order.created_at).getTime() / 1000;
  const currentTime = Math.floor(Date.now() / 1000);
  const timeDiff = currentTime - orderTime;

  if (timeDiff > ORDER_TIMEOUT) {
    await api.updateOrderStatus(order.deposit_code, "expired");
    return editMessageSmart(
      chatId,
      messageId,
      `\u274c <b>Pesanan telah expired!</b>\n\nPembayaran tidak dilakukan dalam waktu 25 menit.\n\nSilakan buat pesanan baru.`,
      getBackButton(backAction)
    );
  }

  const paymentResult = await api.checkPaymentStatus(order.deposit_code);

  if (paymentResult.isPaid) {
    await processSuccessfulPayment(chatId, messageId, order);
  } else {
    const remainingTime = ORDER_TIMEOUT - timeDiff;
    const remainingMinutes = Math.floor(remainingTime / 60);
    const remainingSeconds = Math.floor(remainingTime % 60);

    const statusMessage =
      `\u23f3 <b>Status Pembayaran: PENDING</b>\n\n` +
      `Pembayaran Anda masih dalam proses.\n\n` +
      `\u23f0 <b>Sisa Waktu:</b> ${remainingMinutes}m ${remainingSeconds}s\n` +
      `\ud83d\udd04 <b>Cek otomatis setiap 20 detik</b>\n\n` +
      `Silakan tunggu beberapa saat dan coba lagi.`;

    const checkAction =
      backAction === "extend_user" ? "check_extend" : "check_payment";
    const keyboard = JSON.stringify({
      inline_keyboard: [
        [{ text: "\ud83d\udd04 Cek Lagi", callback_data: checkAction }],
        [{ text: "\u274c Batalkan", callback_data: "cancel_order" }],
      ],
    });

    return editMessageSmart(chatId, messageId, statusMessage, keyboard);
  }
}

// ============================================================
// REDEEM POINTS MENU
// ============================================================

async function showRedeemPointsMenu(chatId: string, messageId?: number) {
  const userPoints = await api.getUserPoints(chatId);

  const message =
    `\ud83c\udf81 <b>TUKAR POINT</b>\n\n` +
    `\ud83d\udcb0 <b>Point Anda:</b> ${userPoints} points\n\n` +
    `\ud83d\udcca <b>Rate Penukaran:</b>\n` +
    `\u2022 1 Hari = 12 points\n` +
    `\u2022 2 Hari = 24 points\n` +
    `\u2022 3 Hari = 36 points\n` +
    `\u2022 7 Hari = 84 points\n\n` +
    `Pilih durasi yang ingin ditukar:`;

  const keyboard = JSON.stringify({
    inline_keyboard: [
      [
        { text: "1 Hari - 12 points", callback_data: "redeem_1" },
        { text: "2 Hari - 24 points", callback_data: "redeem_2" },
      ],
      [
        { text: "3 Hari - 36 points", callback_data: "redeem_3" },
        { text: "7 Hari - 84 points", callback_data: "redeem_7" },
      ],
      [{ text: "\u21a9\ufe0f Kembali", callback_data: "main_menu" }],
    ],
  });

  if (messageId) {
    return editMessageSmart(chatId, messageId, message, keyboard);
  }
  return sendMessageWithImage(chatId, message, keyboard);
}

async function processPointRedemption(
  chatId: string,
  duration: number,
  messageId: number
) {
  const userPoints = await api.getUserPoints(chatId);
  const pointsNeeded = calculatePointsNeededForDays(duration);

  if (userPoints < pointsNeeded) {
    const message =
      `\u274c <b>Point tidak cukup!</b>\n\n` +
      `Point yang dibutuhkan: <b>${pointsNeeded} points</b>\n` +
      `Point Anda: <b>${userPoints} points</b>\n\n` +
      `Silakan kumpulkan point lebih banyak dengan melakukan pembelian.`;

    return editMessageSmart(
      chatId,
      messageId,
      message,
      getBackButton("redeem_points")
    );
  }

  const message =
    `\ud83c\udfae <b>PILIH JENIS GAME</b>\n\n` +
    `Anda akan menukar <b>${pointsNeeded} points</b> untuk lisensi <b>${duration} hari</b>\n\n` +
    `Pilih jenis Free Fire:`;

  const keyboard = JSON.stringify({
    inline_keyboard: [
      [
        { text: "\ud83c\udfae FREE FIRE", callback_data: "redeem_ff" },
        {
          text: "\u26a1 FREE FIRE MAX",
          callback_data: "redeem_ffmax",
        },
      ],
      [{ text: "\u21a9\ufe0f Kembali", callback_data: "redeem_points" }],
    ],
  });

  await api.saveUserState(chatId, "waiting_redeem_game", {
    duration,
    points_needed: pointsNeeded,
  });

  return editMessageSmart(chatId, messageId, message, keyboard);
}

async function completePointRedemption(
  chatId: string,
  gameType: string,
  duration: number,
  messageId: number
) {
  const pointsNeeded = calculatePointsNeededForDays(duration);
  const userPoints = await api.getUserPoints(chatId);

  if (userPoints < pointsNeeded) {
    return editMessageSmart(
      chatId,
      messageId,
      `\u274c <b>Point tidak cukup!</b>\n\nPoint yang dibutuhkan: <b>${pointsNeeded} points</b>\nPoint Anda: <b>${userPoints} points</b>`,
      getBackButton("redeem_points")
    );
  }

  let credentials = generateRedeemCredentials();
  const table = gameType === "ff" ? "freefire" : "ffmax";

  // Check unique username
  let attempts = 0;
  while ((await api.checkUsername(credentials.username, table)) && attempts < 10) {
    credentials = generateRedeemCredentials();
    attempts++;
  }

  if (attempts >= 10) {
    return editMessageSmart(
      chatId,
      messageId,
      "\u274c <b>Gagal generate username unik!</b>\n\nSilakan coba lagi.",
      getBackButton("redeem_points")
    );
  }

  const gameName = gameType === "ff" ? "FREE FIRE" : "FREE FIRE MAX";

  // Deduct points first
  const redeemed = await api.redeemUserPoints(
    chatId,
    pointsNeeded,
    `Penukaran lisensi ${duration} hari`
  );

  if (!redeemed) {
    return editMessageSmart(
      chatId,
      messageId,
      "\u274c <b>Gagal menukar point!</b>\n\nTerjadi kesalahan sistem. Silakan coba lagi.",
      getBackButton("redeem_points")
    );
  }

  // Save license
  const saved = await api.saveLicense(
    table,
    credentials.username,
    credentials.password,
    duration,
    "DIMZ1945"
  );

  if (saved) {
    const now = new Date();
    const expiry = new Date(now.getTime() + duration * 24 * 60 * 60 * 1000);
    const expiryDate = formatDateWIB(expiry);
    const newUserPoints = await api.getUserPoints(chatId);

    const message =
      `\ud83c\udf89 <b>PENUKARAN POINT BERHASIL!</b>\n\n` +
      `Anda berhasil menukar <b>${pointsNeeded} points</b>\n` +
      `Untuk lisensi <b>${gameName}</b> selama <b>${duration} hari</b>\n\n` +
      `\ud83d\udcf1 <b>AKUN ANDA:</b>\n` +
      `Username: <code>${credentials.username}</code>\n` +
      `Password: <code>${credentials.password}</code>\n` +
      `Tipe Key: <b>REDEEM (AUTO RANDOM)</b>\n\n` +
      `\u23f0 <b>MASA AKTIF:</b>\n` +
      `Berlaku hingga: <b>${expiryDate} WIB</b>\n\n` +
      `\ud83c\udfae <b>JENIS GAME:</b> ${gameName}\n` +
      `\ud83d\udcb0 <b>SISA POINT:</b> ${newUserPoints} points\n\n` +
      `\u2728 <b>Selamat bermain!</b> \ud83c\udfae\n\n` +
      `\ud83d\udcc1 <b>Untuk file dan tutorial instalasi:</b>\n` +
      `Klik tombol '\ud83d\udcc1 File & Cara Pasang' di bawah`;

    const keyboard = JSON.stringify({
      inline_keyboard: [
        [
          {
            text: "\ud83d\udcc1 File & Cara Pasang",
            url: "https://t.me/+RY2yMHn_jts3YzA1",
          },
        ],
        [
          {
            text: "\ud83c\udf81 Tukar Lagi",
            callback_data: "redeem_points",
          },
          {
            text: "\ud83d\uded2 Beli Lisensi",
            callback_data: "new_order",
          },
        ],
        [{ text: "\ud83c\udfe0 Menu Utama", callback_data: "main_menu" }],
      ],
    });

    const { WELCOME_IMAGE } = await import("./bot-config");
    await sendPhoto(chatId, WELCOME_IMAGE, message, keyboard);

    // Notify admin
    const adminMsg =
      `\ud83c\udf81 <b>PENUKARAN POINT BARU!</b>\n\n` +
      `User ID: <code>${chatId}</code>\n` +
      `Jenis Game: <b>${gameName}</b>\n` +
      `Durasi: <b>${duration} Hari</b>\n` +
      `Tipe Key: <b>REDEEM (AUTO RANDOM)</b>\n` +
      `Username: <code>${credentials.username}</code>\n` +
      `Password: <code>${credentials.password}</code>\n` +
      `Point Ditukar: <b>${pointsNeeded} points</b>\n` +
      `Masa Aktif: <b>${expiryDate} WIB</b>\n` +
      `Waktu: ${formatDateWIB(new Date())}`;
    await notifyAdmin(adminMsg);
  } else {
    // Refund points
    await api.addUserPoints(chatId, pointsNeeded, "Refund gagal penukaran");
    await editMessageSmart(
      chatId,
      messageId,
      "\u274c <b>Gagal membuat lisensi!</b>\n\nPoint telah dikembalikan. Silakan coba lagi.",
      getBackButton("redeem_points")
    );
  }
}

// ============================================================
// REAL-TIME PAYMENT CHECK PROCESSING
// ============================================================

export async function processRealTimePaymentChecks() {
  const checks = await api.getActivePaymentChecks();
  const currentTime = Math.floor(Date.now() / 1000);

  for (const check of checks) {
    if (check.status !== "active") continue;

    const chatId = check.chat_id;
    const messageId = parseInt(check.message_id);

    // Expired
    if (currentTime >= check.end_time) {
      await api.updatePaymentCheck(check.id, currentTime, "expired");
      continue;
    }

    // Check interval
    if (currentTime >= check.last_check + PAYMENT_CHECK_INTERVAL) {
      const order = await api.getPendingOrder(chatId);
      if (order) {
        const paymentResult = await api.checkPaymentStatus(
          order.deposit_code
        );
        if (paymentResult.isPaid) {
          await processSuccessfulPayment(chatId, messageId, order);
          await api.updatePaymentCheck(check.id, currentTime, "completed");
          continue;
        }
      }
      await api.updatePaymentCheck(check.id, currentTime, "active");
    }
  }
}

// ============================================================
// AUTO-DELETE PROCESSING
// ============================================================

export async function processAutoDelete() {
  const schedules = await api.getDueSchedules();

  for (const schedule of schedules) {
    const chatId = schedule.chat_id;
    const order = await api.getPendingOrder(chatId);

    // Only delete if order is still pending (not completed)
    if (!order || order.status === "pending") {
      await deleteMessage(chatId, parseInt(schedule.message_id));
    }
    await api.deleteMessageSchedule(chatId, schedule.message_id);
  }
}

// ============================================================
// DATE HELPERS
// ============================================================

function formatDateWIB(date: Date): string {
  return date.toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function formatDateFromDB(dateStr: string): string {
  const date = new Date(dateStr);
  return formatDateWIB(date);
}

function calculateNewExpDate(currentExpDate: string, durationDays: number): string {
  const current = new Date(currentExpDate);
  const now = new Date();

  const base = current.getTime() < now.getTime() ? now : current;
  const newDate = new Date(
    base.getTime() + durationDays * 24 * 60 * 60 * 1000
  );
  return formatDateWIB(newDate);
}
