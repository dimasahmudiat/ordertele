// Points calculation and credential generation utilities
import { POINT_RATES, POINTS_PER_DAY_REDEEM } from "./bot-config";

export function calculatePointsForDuration(duration: number): number {
  return POINT_RATES[duration] || Math.ceil(duration * 0.6);
}

export function calculatePointsNeededForDays(days: number): number {
  return days * POINTS_PER_DAY_REDEEM;
}

export function generateRandomCredentials(): {
  username: string;
  password: string;
} {
  const letters = "abcdefghijklmnopqrstuvwxyz";
  const digits = "0123456789";

  let username = "";
  for (let i = 0; i < 2; i++)
    username += letters[Math.floor(Math.random() * letters.length)];
  for (let i = 0; i < 2; i++)
    username += digits[Math.floor(Math.random() * digits.length)];

  let password = "";
  for (let i = 0; i < 2; i++)
    password += digits[Math.floor(Math.random() * digits.length)];

  return { username, password };
}

export function generateRedeemCredentials(): {
  username: string;
  password: string;
} {
  const letters = "abcdefghijklmnopqrstuvwxyz";
  const digits = "0123456789";

  let suffix = "";
  for (let i = 0; i < 3; i++)
    suffix += letters[Math.floor(Math.random() * letters.length)];
  for (let i = 0; i < 2; i++)
    suffix += digits[Math.floor(Math.random() * digits.length)];

  const username = "redeem" + suffix;
  const password = digits[Math.floor(Math.random() * digits.length)];

  return { username, password };
}
