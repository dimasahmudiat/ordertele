// Bot configuration - prices, timeouts, point rates

export const BOT_TOKEN = process.env.BOT_TOKEN || "";
export const API_SECRET_KEY = process.env.API_SECRET_KEY || "";
export const API_BASE_URL =
  process.env.API_BASE_URL || "https://dimzmods.my.id/botorder/api.php";
export const WELCOME_IMAGE = process.env.WELCOME_IMAGE || "";
export const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID || "";
export const MERCHANT_CODE = "DIMZ1945";

export const ORDER_TIMEOUT = 1500; // 25 minutes in seconds
export const PAYMENT_CHECK_INTERVAL = 20; // 20 seconds

// Price list (duration in days => price in Rupiah)
export const PRICES: Record<string, number> = {
  "1": 15000,
  "2": 30000,
  "3": 40000,
  "4": 50000,
  "5": 60000,
  "6": 70000,
  "7": 80000,
  "8": 90000,
  "10": 100000,
  "15": 150000,
  "20": 180000,
  "30": 250000,
};

// Point rates
export const POINT_RATES: Record<number, number> = {
  1: 1,
  2: 1,
  3: 2,
  4: 3,
  5: 4,
  6: 4,
  7: 5,
  8: 6,
  10: 7,
  15: 10,
  20: 13,
  30: 18,
};

export const POINTS_PER_DAY_REDEEM = 12; // 12 points = 1 hari

export function formatPrice(amount: number): string {
  return new Intl.NumberFormat("id-ID").format(amount);
}
