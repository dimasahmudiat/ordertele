// Telegram Bot API wrapper
import { BOT_TOKEN } from "./bot-config";

const BASE_URL = `https://api.telegram.org/bot${BOT_TOKEN}`;

async function telegramRequest(method: string, data: Record<string, unknown>) {
  const res = await fetch(`${BASE_URL}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function sendMessage(
  chatId: string | number,
  text: string,
  replyMarkup?: string,
  disableWebPagePreview = true
) {
  const data: Record<string, unknown> = {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: disableWebPagePreview,
  };
  if (replyMarkup) data.reply_markup = JSON.parse(replyMarkup);
  return telegramRequest("sendMessage", data);
}

export async function sendPhoto(
  chatId: string | number,
  photoUrl: string,
  caption: string,
  replyMarkup?: string
) {
  const data: Record<string, unknown> = {
    chat_id: chatId,
    photo: photoUrl,
    caption,
    parse_mode: "HTML",
  };
  if (replyMarkup) data.reply_markup = JSON.parse(replyMarkup);
  return telegramRequest("sendPhoto", data);
}

export async function editMessageText(
  chatId: string | number,
  messageId: number,
  text: string,
  replyMarkup?: string
) {
  const data: Record<string, unknown> = {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: "HTML",
  };
  if (replyMarkup) data.reply_markup = JSON.parse(replyMarkup);
  return telegramRequest("editMessageText", data);
}

export async function editMessageCaption(
  chatId: string | number,
  messageId: number,
  caption: string,
  replyMarkup?: string
) {
  const data: Record<string, unknown> = {
    chat_id: chatId,
    message_id: messageId,
    caption,
    parse_mode: "HTML",
  };
  if (replyMarkup) data.reply_markup = JSON.parse(replyMarkup);
  return telegramRequest("editMessageCaption", data);
}

/**
 * Smart edit - try caption first (for photos), then text, then send new
 */
export async function editMessageSmart(
  chatId: string | number,
  messageId: number,
  text: string,
  replyMarkup?: string
) {
  // Try editing as caption first
  const captionResult = await editMessageCaption(
    chatId,
    messageId,
    text,
    replyMarkup
  );
  if (captionResult?.ok) return captionResult;

  // Try editing as text
  const textResult = await editMessageText(
    chatId,
    messageId,
    text,
    replyMarkup
  );
  if (textResult?.ok) return textResult;

  // Fallback: send new message with image
  return sendMessageWithImage(chatId, text, replyMarkup);
}

export async function sendMessageWithImage(
  chatId: string | number,
  text: string,
  replyMarkup?: string
) {
  const { WELCOME_IMAGE } = await import("./bot-config");
  if (WELCOME_IMAGE) {
    const photoResult = await sendPhoto(chatId, WELCOME_IMAGE, text, replyMarkup);
    if (photoResult?.ok) return photoResult;
  }
  // Fallback to text
  return sendMessage(chatId, text, replyMarkup);
}

export async function deleteMessage(
  chatId: string | number,
  messageId: number
) {
  return telegramRequest("deleteMessage", {
    chat_id: chatId,
    message_id: messageId,
  });
}

export async function answerCallbackQuery(
  callbackId: string,
  text?: string
) {
  const data: Record<string, unknown> = { callback_query_id: callbackId };
  if (text) data.text = text;
  return telegramRequest("answerCallbackQuery", data);
}

// Broadcast media types
export async function sendBroadcastMessage(
  chatId: string | number,
  messageType: string,
  fileId: string,
  caption: string
) {
  switch (messageType) {
    case "photo":
      return telegramRequest("sendPhoto", {
        chat_id: chatId,
        photo: fileId,
        caption,
        parse_mode: "HTML",
      });
    case "video":
      return telegramRequest("sendVideo", {
        chat_id: chatId,
        video: fileId,
        caption,
        parse_mode: "HTML",
      });
    case "document":
      return telegramRequest("sendDocument", {
        chat_id: chatId,
        document: fileId,
        caption,
        parse_mode: "HTML",
      });
    case "audio":
      return telegramRequest("sendAudio", {
        chat_id: chatId,
        audio: fileId,
        caption,
        parse_mode: "HTML",
      });
    case "text":
    default:
      return sendMessage(chatId, caption);
  }
}
